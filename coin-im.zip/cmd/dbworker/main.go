package main

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	"coin-im/config"
	"coin-im/internal/common"
	"coin-im/internal/dao"
	"coin-im/internal/dbworker"
	"coin-im/pkg/remotecfg"
	"coin-im/pkg/util"

	"github.com/creasty/defaults"
	_ "github.com/go-sql-driver/mysql"
	"github.com/kelseyhightower/envconfig"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

func NewLogger() *zap.Logger {
	//logConfig := zap.NewProductionConfig()
	logConfig := zap.NewDevelopmentConfig()
	logConfig.EncoderConfig.TimeKey = "time"
	logConfig.EncoderConfig.EncodeTime = zapcore.ISO8601TimeEncoder

	logger, _ := logConfig.Build(
		zap.AddCaller(),
		zap.AddStacktrace(zap.ErrorLevel),
		zap.Fields(zap.String("@service", "coin-im-dbworker")),
	)

	return logger
}

func main() {
	remotecfg.InitConfig()
	remotecfg.ConfigCenter.RegisterConfig("im", "/config")
	imCfg := remotecfg.ConfigCenter.GetConfig("im")

	conf := new(config.RemoteConfig)
	util.Must(defaults.Set(conf))
	util.Must(imCfg.Unmarshal(conf))

	kafkaEnv := new(config.KafkaEnvConfig)
	err := envconfig.Process("im", kafkaEnv)
	util.Must(err)
	conf.KafkaEnv = kafkaEnv

	if conf.Debug {
		envconfig.Usage("im", remotecfg.Env)
		fmt.Println()
		envconfig.Usage("im", kafkaEnv)
		fmt.Println()
	}

	logger := NewLogger()

	db := common.NewDB(conf)

	rdb := common.NewRdb(conf.Redis)

	_dao := dao.NewDao(conf, db, rdb, nil, logger)

	worker := dbworker.NewDBWorker(conf, _dao, rdb, logger)
	go worker.KafkaConsume2Redis()
	go worker.KafkaConsume2MySQL()

	// graceful stop
	quit := make(chan os.Signal)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	logger.Info("Shutting down dbworker...")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	util.Must(worker.Close(ctx))
}
