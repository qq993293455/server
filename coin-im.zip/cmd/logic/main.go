package main

import (
	"context"
	"fmt"
	"net/http"
	_ "net/http/pprof"
	"os"
	"os/signal"
	"syscall"
	"time"

	"coin-im/config"
	"coin-im/internal/common"
	"coin-im/internal/dao"
	"coin-im/internal/logic"
	"coin-im/internal/sensitive"
	"coin-im/pkg/remotecfg"
	"coin-im/pkg/reuseport"
	"coin-im/pkg/util"

	"github.com/creasty/defaults"
	_ "github.com/go-sql-driver/mysql"
	"github.com/kelseyhightower/envconfig"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

func NewLogger() *zap.Logger {
	//logConfig := zap.NewProductionConfig()
	logConfig := zap.NewDevelopmentConfig()
	logConfig.EncoderConfig.TimeKey = "time"
	logConfig.EncoderConfig.EncodeTime = zapcore.ISO8601TimeEncoder

	logger, _ := logConfig.Build(
		zap.AddCaller(),
		zap.AddStacktrace(zap.ErrorLevel),
		zap.Fields(zap.String("@service", "coin-im-logic")),
	)

	return logger
}

func NewHttpServer(conf *config.RemoteConfig, logger *zap.Logger) (*http.Server, *logic.Handler) {
	logger.Debug("config", zap.Any("conf", conf))

	db := common.NewDB(conf)

	rdb := common.NewRdb(conf.Redis)
	mdb := common.NewRdb(conf.MemoryDB)

	_dao := dao.NewDao(conf, db, rdb, mdb, logger)

	httpHandler := logic.NewHandler(conf, _dao, rdb, logger)

	httpRouter := logic.NewRouter(httpHandler, logger, conf.Debug)

	return &http.Server{
		Addr:    conf.HttpAddr,
		Handler: httpRouter,
	}, httpHandler
}

func main() {
	remotecfg.InitConfig()
	remotecfg.ConfigCenter.RegisterConfig("im", "/config")
	imCfg := remotecfg.ConfigCenter.GetConfig("im")

	conf := new(config.RemoteConfig)
	util.Must(defaults.Set(conf))
	util.Must(imCfg.Unmarshal(conf))

	kafkaEnv := new(config.KafkaEnvConfig)
	err := envconfig.Process("im", kafkaEnv)
	util.Must(err)
	conf.KafkaEnv = kafkaEnv

	if conf.Debug {
		envconfig.Usage("im", remotecfg.Env)
		fmt.Println()
		envconfig.Usage("im", kafkaEnv)
		fmt.Println()
	}

	sensitive.Init(conf) // 初始化敏感词

	logger := NewLogger()

	// HTTP
	httpSvr, httpHandler := NewHttpServer(conf, logger)
	go func() { // http
		logger.Info(fmt.Sprintf("Listening and serving HTTP on %s", conf.HttpAddr))
		l, err := reuseport.Listen("tcp4", conf.HttpAddr)
		if err != nil {
			panic(err)
		}
		if err := httpSvr.Serve(l); err != nil && err != http.ErrServerClosed {
			logger.Fatal("listen error", zap.Error(err))
		}
	}()
	if conf.HttpsAddr != "" {
		go func() { // https
			logger.Info(fmt.Sprintf("Listening and serving HTTPS on %s", conf.HttpsAddr))
			l, err := reuseport.Listen("tcp4", conf.HttpsAddr)
			if err != nil {
				panic(err)
			}
			if err := httpSvr.ServeTLS(l, "cert.pem", "key.pem"); err != nil && err != http.ErrServerClosed {
				logger.Fatal("listen error", zap.Error(err))
			}
		}()
	}
	go func() {
		logger.Info("pprof start:", zap.String("addr", conf.LogicPprofAddr))
		logger.Error("pprof exit", zap.Error(http.ListenAndServe(conf.LogicPprofAddr, nil)))
	}()
	// graceful stop
	quit := make(chan os.Signal)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	logger.Info("Shutting down server...")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	httpHandler.Close()
	if err := httpSvr.Shutdown(ctx); err != nil {
		logger.Fatal("Server forced to shutdown:", zap.Error(err))
	}
}
