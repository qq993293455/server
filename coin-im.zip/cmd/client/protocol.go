package main

import (
	"encoding/binary"

	"github.com/Allenxuxu/ringbuffer"
)

const (
	OpPing = uint16(1)
	OpPong = uint16(2)

	// OpAuth auth connnect
	OpAuth = uint16(7)
	// OpAuthReply auth connect reply
	OpAuthReply = uint16(8)

	// OpRaw raw message
	OpRaw = uint16(9)
)

const (
	// size
	_packSize      = 4
	_headerSize    = 2
	_opSize        = 2
	_rawHeaderSize = _packSize + _headerSize + _opSize

	_headerLen = _opSize

	// offset
	_packOffset   = 0
	_headerOffset = _packOffset + _packSize
	_opOffset     = _headerOffset + _opSize
)

// Message | packLen 4B | headerLen 2B | op 2B | body ... |
type Message struct {
	Op   uint16
	Body []byte
}

func UnPacket(buffer *ringbuffer.RingBuffer) (op uint16, out []byte) {
	if buffer.Length() < _rawHeaderSize {
		return
	}

	length := buffer.PeekUint32()
	if buffer.Length() < int(length) {
		return
	}
	buffer.Retrieve(_packSize)

	headerLen := buffer.PeekUint16()
	buffer.Retrieve(_headerSize)

	op = buffer.PeekUint16()
	buffer.Retrieve(_opSize)

	dataLen := length - _packSize - uint32(headerLen) - _headerSize
	out = make([]byte, dataLen)
	buffer.Read(out)

	return
}

func Packet(data *Message) []byte {
	dataLen := len(data.Body)
	packLen := uint32(dataLen + _rawHeaderSize)
	ret := make([]byte, packLen)

	binary.BigEndian.PutUint32(ret, packLen)
	binary.BigEndian.PutUint16(ret[_headerOffset:], _headerLen)
	binary.BigEndian.PutUint16(ret[_opOffset:], data.Op)
	copy(ret[_rawHeaderSize:], data.Body)

	return ret
}
