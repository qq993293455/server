package main

import (
	"encoding/binary"
	"flag"
	"io"
	"log"
	"net"
	"time"

	"github.com/Allenxuxu/ringbuffer"
)

func must(err error) {
	if err != nil {
		panic(err)
	}
}

var (
	token = flag.String("token", "123", "im token")
	addr  = flag.String("addr", "localhost:9527", "im server 地址")
)

func main() {
	flag.Parse()

	cli, err := net.Dial("tcp", *addr)
	must(err)
	defer cli.Close()

	authData := Packet(&Message{
		Op:   OpAuth,
		Body: []byte(*token),
	})
	log.Printf("SEND -> Op: %d\n", OpAuth)
	_, err = cli.Write(authData)
	must(err)

	go ping(cli)
	receiver(cli)
}

func receiver(c net.Conn) {
	for {
		sizeBuf := make([]byte, 4)
		_, err := io.ReadAtLeast(c, sizeBuf, _packSize)
		if err != nil {
			log.Println(err)
			return
		}

		dataLen := int(binary.BigEndian.Uint32(sizeBuf)) - 4
		data := make([]byte, dataLen)
		_, err = io.ReadAtLeast(c, data, dataLen)
		if err != nil {
			log.Println(err)
			return
		}

		op, out := UnPacket(ringbuffer.NewWithData(append(sizeBuf, data...)))
		log.Printf("RECV -> Op: %d, Out: %s\n", op, out)
	}
}

const (
	PingInterval = 10 * time.Second
	PingTimeout  = 3 * PingInterval
)

func ping(c net.Conn) {
	for range time.Tick(PingInterval) {
		data := Packet(&Message{
			Op: OpPing,
		})
		log.Printf("SEND -> Op: %d\n", OpPing)
		_, err := c.Write(data)
		must(err)
	}
}
