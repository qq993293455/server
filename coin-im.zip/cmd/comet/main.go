package main

import (
	"context"
	"fmt"
	"net/http"
	_ "net/http/pprof"
	"os"
	"os/signal"
	"syscall"
	"time"

	"coin-im/config"
	"coin-im/internal/comet"
	"coin-im/internal/common"
	"coin-im/internal/dao"
	"coin-im/pkg/remotecfg"
	"coin-im/pkg/ulimit"
	"coin-im/pkg/util"
	"github.com/creasty/defaults"
	_ "github.com/go-sql-driver/mysql"
	"github.com/kelseyhightower/envconfig"
	"github.com/panjf2000/ants/v2"
	"github.com/panjf2000/gnet"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

func NewLogger() *zap.Logger {
	//logConfig := zap.NewProductionConfig()
	logConfig := zap.NewDevelopmentConfig()
	logConfig.EncoderConfig.TimeKey = "time"
	logConfig.EncoderConfig.EncodeTime = zapcore.ISO8601TimeEncoder

	logger, _ := logConfig.Build(
		zap.AddCaller(),
		zap.AddStacktrace(zap.ErrorLevel),
		zap.Fields(zap.String("@service", "coin-im-comet")),
	)

	return logger
}

func main() {

	remotecfg.InitConfig()
	remotecfg.ConfigCenter.RegisterConfig("im", "/config")
	imCfg := remotecfg.ConfigCenter.GetConfig("im")

	conf := new(config.RemoteConfig)
	util.Must(defaults.Set(conf))
	util.Must(imCfg.Unmarshal(conf))

	kafkaEnv := new(config.KafkaEnvConfig)
	err := envconfig.Process("im", kafkaEnv)
	util.Must(err)
	conf.KafkaEnv = kafkaEnv

	if conf.Debug {
		envconfig.Usage("im", remotecfg.Env)
		fmt.Println()
		envconfig.Usage("im", kafkaEnv)
		fmt.Println()
	}

	logger := NewLogger()

	gopool, err := ants.NewPool(2048)
	util.Must(err)

	hub := comet.NewHub(conf, gopool, logger)

	//db := common.NewDB(conf)
	//
	//rdb := common.NewRdb(conf.Redis)
	mdb := common.NewRdb(conf.MemoryDB)

	_dao := dao.NewDao(conf, nil, nil, mdb, logger)

	// TCP
	tcpHandler := comet.NewHandler(gopool, hub, logger, conf, _dao)
	logger.Info("IM Server Listening : " + conf.TcpAddr)
	go func() {
		err = ulimit.SetRLimit()
		if err != nil {
			panic(err)
		}
		err = gnet.Serve(tcpHandler,
			conf.TcpAddr,
			gnet.WithMulticore(true),
			gnet.WithTCPKeepAlive(time.Minute*5),
			gnet.WithCodec(comet.Protocol),
			gnet.WithReusePort(true))
		if err != nil {
			panic(err)
		}
	}()
	go func() {
		logger.Info("pprof start:", zap.String("addr", conf.PprofAddr))
		logger.Error("pprof exit", zap.Error(http.ListenAndServe(conf.PprofAddr, nil)))
	}()
	// graceful stop
	quit := make(chan os.Signal)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	logger.Info("Shutting down server...")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	util.Must(hub.Close(ctx))
	util.Must(gnet.Stop(ctx, conf.TcpAddr))
}
