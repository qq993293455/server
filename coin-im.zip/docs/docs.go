package docs

import "embed"

//go:embed swagger.yaml
var SwaggerFs embed.FS
