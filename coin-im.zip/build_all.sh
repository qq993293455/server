#!/bin/bash

set -e
set -x

rm -rf ./bin
mkdir -p ./bin
echo "go build start ..."

GOOS=linux GOARCH=amd64 go build -o ./bin/comet ./cmd/comet/main.go;
GOOS=linux GOARCH=amd64 go build -o ./bin/dbworker ./cmd/dbworker/main.go;
GOOS=linux GOARCH=amd64 go build -o ./bin/logic ./cmd/logic/main.go;
echo "go build done"

dStr=`date "+%Y-%m-%d %H:%M:%S"`
dStr=`echo $dStr|sed 's/\ /_/g'|sed 's/:/_/g'`

tar -zcvf im-${dStr}.tar.gz ./bin/*

expect scp_tar.sh im-${dStr}.tar.gz
