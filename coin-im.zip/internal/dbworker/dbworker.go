package dbworker

import (
	"context"
	"sync"
	"sync/atomic"
	"time"

	cometpb "coin-im/api/comet"
	"coin-im/config"
	"coin-im/internal/common"
	"coin-im/internal/dao"
	"coin-im/internal/model"

	"github.com/go-redis/redis/v8"
	"github.com/segmentio/kafka-go"
	"go.uber.org/zap"
)

type DBWorker struct {
	conf     *config.RemoteConfig
	dao      *dao.Dao
	log      *zap.Logger
	kr       *kafka.Reader
	kr2redis *kafka.Reader // 消费redis消息
	rdb      *redis.Client
	close    chan struct{}
	closed1  int32
	closed2  int32

	batchDBMsg  map[cometpb.MsgType][]model.Message
	batchRdbMsg map[string][]interface{}
	roomKeys    map[string]string
}

func NewDBWorker(conf *config.RemoteConfig, _dao *dao.Dao, rdb *redis.Client, log *zap.Logger) *DBWorker {
	kr := kafka.NewReader(kafka.ReaderConfig{
		Brokers:        conf.KafkaAddr,
		GroupID:        conf.KafkaEnv.DBWorkerGroup,
		Topic:          conf.KafkaTopic,
		MinBytes:       1,
		MaxBytes:       50e6, // 50MB
		CommitInterval: 10 * time.Millisecond,
	})

	kr2 := kafka.NewReader(kafka.ReaderConfig{
		Brokers:        conf.KafkaAddr,
		GroupID:        conf.KafkaEnv.DBWorkerRedisGroup,
		Topic:          conf.KafkaTopic,
		MinBytes:       1,
		MaxBytes:       50e6, // 50MB
		CommitInterval: 10 * time.Millisecond,
	})

	return &DBWorker{
		conf:     conf,
		dao:      _dao,
		log:      log,
		kr:       kr,
		kr2redis: kr2,
		rdb:      rdb,
		close:    make(chan struct{}),
		batchDBMsg: map[cometpb.MsgType][]model.Message{
			cometpb.MsgType_Private:   make([]model.Message, 0, 200),
			cometpb.MsgType_Room:      make([]model.Message, 0, 200),
			cometpb.MsgType_Broadcast: make([]model.Message, 0, 200),
		},
		batchRdbMsg: map[string][]interface{}{
			common.RdbBroadcastListKey: make([]interface{}, 0, 100),
		},
		roomKeys: map[string]string{},
	}
}

var (
	protoPool   = sync.Pool{New: func() interface{} { return new(cometpb.Proto) }}
	messagePool = sync.Pool{New: func() interface{} { return new(cometpb.Message) }}
	dbMsgPool   = sync.Pool{New: func() interface{} { return new(model.Message) }}
)

func protoPoolPut(p *cometpb.Proto) {
	p.Reset()
	protoPool.Put(p)
}

func messagePoolPut(p *cometpb.Message) {
	p.Reset()
	messagePool.Put(p)
}

func dbMsgPoolPut(p *model.Message) {
	p.Reset()
	dbMsgPool.Put(p)
}

func (d *DBWorker) KafkaConsume2MySQL() {
	ctx := context.Background()
	prevTime := time.Now()
	var mcount int
	var proto *cometpb.Proto
	var msg *kafka.Message

	for {
		select {
		case <-d.close:
			atomic.StoreInt32(&d.closed1, 1)
			return
		default:
		}
		fetchCtx, cancel := context.WithTimeout(ctx, time.Millisecond*500)
		tempMsg, err := d.kr.FetchMessage(fetchCtx)
		cancel()
		if err != nil {
			if err == context.DeadlineExceeded {
				goto Sync
			}
			d.log.Warn("call kafka.FetchMessage failed", zap.Error(err))
			time.Sleep(200 * time.Millisecond)
			continue
		}

		msg = &tempMsg
		d.log.Info("[mysql] received message.", zap.String("group_id", d.kr.Config().GroupID), zap.String("topic", msg.Topic), zap.Int("partition", msg.Partition), zap.Int64("offset", msg.Offset))

		proto = protoPool.Get().(*cometpb.Proto)
		err = proto.Unmarshal(msg.Value)
		if err != nil {
			d.log.Warn("call proto.Unmarshal failed", zap.Error(err))
			protoPoolPut(proto)
			continue
		}

		switch proto.Type {
		case cometpb.ProtoType_Raw:
			_, mcount = d.mysqlProcess(ctx, proto.Body)
		case cometpb.ProtoType_OpRoom:
		default:
			d.log.Warn("unknown ProtoType", zap.Int32("proto_type", int32(proto.Type)))
		}
		protoPoolPut(proto)

	Sync:
		if mcount >= 200 || time.Now().Sub(prevTime).Milliseconds() >= 200 {
			if msg == nil {
				continue
			}
			for {
				err = d.mysqlBatchSaveAll(ctx)
				if err != nil {
					d.log.Warn("call mysqlBatchSaveAll failed", zap.Error(err))
					time.Sleep(100 * time.Millisecond)
				} else {
					break
				}
			}
			if err = d.kr.CommitMessages(ctx, *msg); err != nil {
				d.log.Warn("call kafka.CommitMessages failed", zap.Error(err))
			}
			d.log.Info("[mysql] commit message.", zap.String("group_id", d.kr.Config().GroupID), zap.String("topic", msg.Topic), zap.Int("partition", msg.Partition), zap.Int64("offset", msg.Offset))
			msg = nil
			prevTime = time.Now()
		}
	}
}

func (d *DBWorker) mysqlProcess(ctx context.Context, body []byte) (mtype cometpb.MsgType, count int) {
	msg := messagePool.Get().(*cometpb.Message)
	defer messagePoolPut(msg)

	err := msg.Unmarshal(body)
	if err != nil {
		d.log.Warn("call msg.Unmarshal failed", zap.Error(err))
		return // continue
	}
	if msg.IsVolatile { // 不落库
		return
	}

	if _, ok := d.batchDBMsg[msg.Type]; !ok {
		d.log.Warn("unknown MsgType", zap.Int32("msg_type", int32(msg.Type)))
		return
	}

	if msg.Extra == "" {
		msg.Extra = "{}"
	}
	d.batchDBMsg[msg.Type] = append(d.batchDBMsg[msg.Type], model.Message{
		Mid:       msg.Mid,
		Type:      int(msg.Type),
		RoleId:    msg.RoleId,
		RoleName:  msg.RoleName,
		TargetId:  msg.TargetId,
		Content:   msg.Content,
		ParseType: msg.ParseType,
		CreatedAt: msg.CreatedAt,
		Extra:     msg.Extra,
	})
	return msg.Type, len(d.batchDBMsg[msg.Type])
}

func (d *DBWorker) mysqlBatchSaveAll(ctx context.Context) (err error) {
	for mtype := range d.batchDBMsg {
		err = d.mysqlBatchSave(ctx, mtype)
		if err != nil {
			return err
		}
	}
	return nil
}

func (d *DBWorker) mysqlBatchSave(ctx context.Context, mtype cometpb.MsgType) (err error) {
	msgs := d.batchDBMsg[mtype]
	if len(msgs) == 0 {
		return nil
	}
	d.log.Info("mysqlBatchSave", zap.String("mtype", mtype.String()), zap.Int("count", len(msgs)))
	switch mtype {
	case cometpb.MsgType_Private:
		err = d.dao.BatchCreatePrivateMessage(ctx, msgs)
	case cometpb.MsgType_Room:
		err = d.dao.BatchCreateRoomMessage(ctx, msgs)
	case cometpb.MsgType_Broadcast:
		err = d.dao.BatchCreateBroadcastMessage(ctx, msgs)
	}
	if err != nil {
		return err
	}
	d.batchDBMsg[mtype] = d.batchDBMsg[mtype][:0]
	return nil
}

func (d *DBWorker) KafkaConsume2Redis() {
	ctx := context.Background()
	prevTime := time.Now()
	var mcount int
	var proto *cometpb.Proto
	var msg *kafka.Message

	for {
		select {
		case <-d.close:
			atomic.StoreInt32(&d.closed2, 1)
			return
		default:
		}
		fetchCtx, cancel := context.WithTimeout(ctx, time.Millisecond*500)
		tempMsg, err := d.kr2redis.FetchMessage(fetchCtx)
		cancel()
		if err != nil {
			if err == context.DeadlineExceeded {
				goto Sync
			}
			d.log.Warn("call kafka.FetchMessage failed", zap.Error(err))
			time.Sleep(200 * time.Millisecond)
			continue
		}

		msg = &tempMsg
		d.log.Info("[redis] received message.", zap.String("group_id", d.kr2redis.Config().GroupID), zap.String("topic", msg.Topic), zap.Int("partition", msg.Partition), zap.Int64("offset", msg.Offset))

		proto = protoPool.Get().(*cometpb.Proto)
		err = proto.Unmarshal(msg.Value)
		if err != nil {
			d.log.Warn("call proto.Unmarshal failed", zap.Error(err))
			protoPoolPut(proto)
			continue
		}

		switch proto.Type {
		case cometpb.ProtoType_Raw:
			_, mcount = d.redisProcess(ctx, proto.Body)
		case cometpb.ProtoType_OpRoom:
		default:
			d.log.Warn("unknown ProtoType", zap.Int32("proto_type", int32(proto.Type)))
		}
		protoPoolPut(proto)

	Sync:
		if mcount >= 100 || time.Now().Sub(prevTime).Milliseconds() >= 100 {
			if msg == nil {
				continue
			}

			for {
				err = d.redisBatchSave(ctx)
				if err != nil {
					d.log.Warn("call redisBatchSave failed", zap.Error(err))
					time.Sleep(100 * time.Millisecond)
				} else {
					break
				}
			}
			if err = d.kr2redis.CommitMessages(ctx, *msg); err != nil {
				d.log.Warn("call kafka.CommitMessages failed", zap.Error(err))
			}
			d.log.Info("[redis] commit message.", zap.String("group_id", d.kr2redis.Config().GroupID), zap.String("topic", msg.Topic), zap.Int("partition", msg.Partition), zap.Int64("offset", msg.Offset))
			msg = nil
			prevTime = time.Now()
		}
	}
}

func (d *DBWorker) redisProcess(ctx context.Context, body []byte) (listKey string, count int) {
	msg := messagePool.Get().(*cometpb.Message)
	defer messagePoolPut(msg)

	err := msg.Unmarshal(body)
	if err != nil {
		d.log.Warn("call msg.Unmarshal failed", zap.Error(err))
		return // continue
	}
	if msg.IsVolatile { // 不落库
		return
	}

	listKey = common.RdbBroadcastListKey
	switch msg.Type {
	case cometpb.MsgType_Private:
		return
	case cometpb.MsgType_Room:
		listKey = common.GenRdbRoomKey(msg.TargetId)
		d.roomKeys[listKey] = msg.TargetId
	case cometpb.MsgType_Broadcast:
	default:
		d.log.Warn("unknown MsgType", zap.Int32("msg_type", int32(msg.Type)))
		return
	}

	data, _ := msg.Marshal()
	d.batchRdbMsg[listKey] = append(d.batchRdbMsg[listKey], data)
	return listKey, len(d.batchRdbMsg[listKey])
}

func (d *DBWorker) redisBatchSave(ctx context.Context) (err error) {
	for listKey, msgs := range d.batchRdbMsg {
		if len(msgs) == 0 {
			continue
		}
		d.log.Info("redisBatchSave", zap.String("list_key", listKey), zap.Int("count", len(msgs)))

		//targetId, isRoom := d.roomKeys[listKey]
		//if isRoom {
		//	exists, err := d.rdb.Exists(ctx, listKey).Result()
		//	if err != nil {
		//		return err
		//	}
		//	if exists == 0 {
		//		d.loadStoreRoomMessage(ctx, targetId)
		//	}
		//}
		size, err := d.rdb.LPush(ctx, listKey, msgs...).Result()
		if err != nil {
			return err
		}
		if size > d.conf.RedisListSize+1000 {
			d.rdb.LTrim(ctx, listKey, 0, d.conf.RedisListSize-1)
		}
		_, isRoom := d.roomKeys[listKey]
		if isRoom {
			d.rdb.Expire(ctx, listKey, d.conf.RedisRoomMsgsExpires)
			delete(d.roomKeys, listKey)
		}
		d.batchRdbMsg[listKey] = d.batchRdbMsg[listKey][:0]
	}
	return nil
}

//func (d *DBWorker) loadStoreRoomMessage(ctx context.Context, targetID string) {
//	log := d.log.With(zap.String("target_id", targetID))
//	retDB, err := d.dao.GetRoomMessageList(ctx, targetID, nil, d.conf.RedisListSize)
//	if err != nil {
//		log.Error("call dao.GetRoomMessageList error", zap.Error(err))
//		return
//	}
//	if len(retDB) != 0 {
//		err = d.dao.StoreMessageListToRdb(ctx, common.GenRdbRoomKey(targetID), retDB)
//		if err != nil {
//			log.Error("call dao.StoreMessageListToRdb error", zap.Error(err))
//			return
//		}
//	}
//}

func (d *DBWorker) Close(ctx context.Context) error {
	close(d.close)
	d.kr.Close()
	d.kr2redis.Close()

	ticker := time.NewTicker(10 * time.Millisecond)
	defer ticker.Stop()

	for {
		if atomic.LoadInt32(&d.closed1) == 1 && atomic.LoadInt32(&d.closed2) == 1 {
			return nil
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
		}
	}
}
