package sensitive

import (
	"fmt"
	"strings"
	"testing"
)

func TestSplitWords(t *testing.T) {
	words := strings.FieldsFunc("你好，hello,fuck|abc_func", isSymbol)
	fmt.Println(words)
}
