package sensitive

import (
	"strings"
	"unicode"
	"unicode/utf8"

	"coin-im/config"
	"coin-im/internal/sensitive/rule"
	"coin-im/pkg/util"

	"github.com/importcjj/sensitive"
)

var (
	fuzzy  = sensitive.New()       // 模糊匹配 表：dict2
	equals = map[string]struct{}{} // 聊天 精确匹配 表：dict1

	_rule *rule.Rule
)

func Init(conf *config.RemoteConfig) {
	_rule = rule.New(conf)
	util.Must(_rule.Load())

	fuzzy.AddWord(_rule.SensitiveDict2.Words()...)

	for _, word := range _rule.SensitiveDict1.Words() {
		equals[strings.ToLower(word)] = struct{}{}
	}
}

// 是否是符号
func isSymbol(r rune) bool {
	return !unicode.IsLetter(r) && !unicode.IsNumber(r)
}

// ChatReplace 替换敏感词为*，不区分大小写
func ChatReplace(str string) string {
	lower := strings.ToLower(str)
	repl := fuzzy.Replace(lower, '*')

	runes := []rune(str)
	for i, word := range []rune(repl) {
		if word == '*' {
			runes[i] = '*'
		}
	}

	words := strings.FieldsFunc(repl, isSymbol) // 简单分词

	idx := 0
	for _, word := range words {
		wordLen := utf8.RuneCountInString(word)
		if _, ok := equals[word]; ok {
			for j := idx; j < idx+wordLen; j++ {
				runes[j] = '*'
			}
		}
		idx += wordLen + 1
	}
	return string(runes)
}

func TextValid(str string) bool {
	lower := strings.ToLower(str)
	valid, _ := fuzzy.Validate(lower)
	if !valid {
		return valid
	}

	words := strings.FieldsFunc(lower, isSymbol) // 简单分词
	for _, word := range words {
		if _, ok := equals[word]; ok {
			return false
		}
	}

	return true
}
