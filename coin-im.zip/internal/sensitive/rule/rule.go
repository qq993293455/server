package rule

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"strings"

	"coin-im/config"
	"coin-im/pkg/util"

	jsoniter "github.com/json-iterator/go"
)

type Response struct {
	Code   int    `json:"code"`
	Error  string `json:"error"`
	Result struct {
		Branch  string      `json:"branch"`
		Version int64       `json:"version"`
		Rule    []TableData `json:"rule"`
	} `json:"result"`
}

type TableData struct {
	Table string `json:"table"`
	Data  string `json:"data"`
}

type SensitiveWord struct {
	Id   int64  `json:"id"`
	Word string `json:"word"`
}

type SensitiveWords []SensitiveWord

func (s SensitiveWords) Words() []string {
	ret := make([]string, len(s))
	for i, v := range s {
		ret[i] = strings.ToLower(v.Word)
	}
	return ret
}

type Rule struct {
	baseAddr string
	client   *http.Client
	conf     *config.RemoteConfig

	SensitiveDict1 SensitiveWords
	SensitiveDict2 SensitiveWords
	SensitiveDict3 SensitiveWords
}

func New(conf *config.RemoteConfig) *Rule {
	return &Rule{
		baseAddr: conf.RuleAddr,
		client:   util.NewHttpClient(),
		conf:     conf,
	}
}

const PathRule = "/v1/rule"

const (
	dict1 = "sensitive_dict1"
	dict2 = "sensitive_dict2"
	dict3 = "sensitive_dict3"
)

func (r *Rule) Load() (err error) {
	q := url.Values{}
	q.Add("branch", r.conf.RuleBranch)
	q.Add("table", dict1)
	q.Add("table", dict2)
	q.Add("table", dict3)

	uri := r.baseAddr + PathRule + "?" + q.Encode()

	resp, err := r.client.Get(uri)
	if err != nil {
		return
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return
	}

	data := new(Response)
	err = jsoniter.Unmarshal(body, data)
	if err != nil {
		return
	}
	if data.Code != 200 {
		panic(fmt.Errorf("获取规则失败，code = %d, err = %s", data.Code, data.Error))
	}

	for _, table := range data.Result.Rule {
		switch table.Table {
		case dict1:
			r.SensitiveDict1 = r.parseSensitiveDict(table.Data)
		case dict2:
			r.SensitiveDict2 = r.parseSensitiveDict(table.Data)
		case dict3:
			r.SensitiveDict3 = r.parseSensitiveDict(table.Data)
		}
	}

	return nil
}

func (r *Rule) parseSensitiveDict(data string) SensitiveWords {
	var words SensitiveWords
	err := jsoniter.UnmarshalFromString(data, &words)
	util.Must(err)
	return words
}
