package common

import (
	"crypto/tls"
	"runtime"
	"time"

	"coin-im/config"
	"coin-im/pkg/util"

	"github.com/go-redis/redis/v8"
	"github.com/jmoiron/sqlx"
)

func NewDB(conf *config.RemoteConfig) *sqlx.DB {
	db, err := sqlx.Connect("mysql", conf.DSN)
	util.Must(err)
	db.SetMaxIdleConns(32)
	db.SetConnMaxIdleTime(60 * time.Second)
	db.SetMaxOpenConns(200)
	db.SetConnMaxLifetime(300 * time.Second)
	return db
}

func NewRdb(conf *config.RedisConfig) *redis.Client {
	opt := &redis.Options{
		Addr:            conf.Addr,
		Password:        conf.Password,
		DB:              conf.DB,
		DialTimeout:     time.Second * 3,
		PoolSize:        runtime.NumCPU() * 25,
		MinIdleConns:    1,
		IdleTimeout:     time.Second * 60,
		MaxRetries:      2,
		MaxRetryBackoff: time.Millisecond * 200,
	}
	if conf.TLS {
		opt.TLSConfig = &tls.Config{}
	}
	return redis.NewClient(opt)
}
