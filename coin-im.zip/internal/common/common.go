package common

import (
	cometpb "coin-im/api/comet"
	"coin-im/internal/model"
)

func TransMessage(src *cometpb.Message, dst *model.Message) {
	dst.Mid = src.Mid
	dst.Type = int(src.Type)
	dst.RoleId = src.RoleId
	dst.RoleName = src.RoleName
	dst.TargetId = src.TargetId
	dst.Content = src.Content
	dst.ParseType = src.ParseType
	dst.CreatedAt = src.CreatedAt
	dst.Extra = src.Extra
	if dst.Extra == "" {
		dst.Extra = "{}"
	}
}

func TransToPbMessage(src *model.Message, dst *cometpb.Message) {
	dst.Mid = src.Mid
	dst.Type = cometpb.MsgType(src.Type)
	dst.RoleId = src.RoleId
	dst.RoleName = src.RoleName
	dst.TargetId = src.TargetId
	dst.Content = src.Content
	dst.ParseType = src.ParseType
	dst.CreatedAt = src.CreatedAt
	dst.Extra = src.Extra
	if dst.Extra == "" {
		dst.Extra = "{}"
	}
}

const (
	RdbBroadcastListKey = "rdb_broadcast_key"
	RdbBaseRoomListKey  = "rdb_room_"
	RdbRoomCount        = "rdb_room_count_"
	BlackListKey        = "im_blacklist_"
)

func GenRdbRoomKey(roomId string) string {
	return RdbBaseRoomListKey + roomId
}

func GenBlackListKey(roleId string) string {
	return BlackListKey + roleId
}
