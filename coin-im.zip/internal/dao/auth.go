package dao

const (
	IdentityKey = "role_id"
	RoleNameKey = "role_name"
	RoomsKey    = "rooms"
	ExtraKey    = "extra"
)

type AuthPayload struct {
	RoleID   string   `form:"role_id"`
	RoleName string   `form:"role_name"`
	Rooms    []string `form:"rooms"`
	Extra    string   `form:"extra"` // 扩展字段  map[string]string 类型的 json 字符串
}
