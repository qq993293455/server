package dao

import (
	"context"
	"sort"

	cometpb "coin-im/api/comet"
	"coin-im/config"
	"coin-im/internal/common"
	"coin-im/internal/model"

	"github.com/go-redis/redis/v8"
	"github.com/jmoiron/sqlx"
	"go.uber.org/zap"
)

type Dao struct {
	conf *config.RemoteConfig
	db   *sqlx.DB
	rdb  *redis.Client
	mdb  *redis.Client // memoryDB
	log  *zap.Logger
}

func NewDao(conf *config.RemoteConfig, db *sqlx.DB, rdb, mdb *redis.Client, log *zap.Logger) *Dao {
	return &Dao{conf: conf, db: db, rdb: rdb, mdb: mdb, log: log}
}

func (d *Dao) CreatePrivateMessage(ctx context.Context, msg *model.Message) error {
	log := d.log.With(zap.Any("private_message", msg))

	query := `INSERT INTO private_message (mid, type, role_id, role_name, target_id, content, parse_type, created_at, extra)
VALUES (:mid, :type, :role_id, :role_name, :target_id, :content, :parse_type, :created_at, :extra)`

	_, err := d.db.NamedExec(query, msg)
	if err != nil {
		log.Warn("db error", zap.Error(err))
	}

	return err
}

func (d *Dao) BatchCreatePrivateMessage(ctx context.Context, msgs []model.Message) error {
	log := d.log.With(zap.Any("private_messages", msgs))

	query := `INSERT IGNORE INTO private_message (mid, type, role_id, role_name, target_id, content, parse_type, created_at, extra)
VALUES (:mid, :type, :role_id, :role_name, :target_id, :content, :parse_type, :created_at, :extra)`

	_, err := d.db.NamedExec(query, msgs)
	if err != nil {
		log.Warn("db error", zap.Error(err))
	}

	return err
}

func (d *Dao) CreateRoomMessage(ctx context.Context, msg *model.Message) error {
	log := d.log.With(zap.Any("room_message", msg))

	query := `INSERT INTO room_message (mid, type, role_id, role_name, target_id, content, parse_type, created_at, extra)
VALUES (:mid, :type, :role_id, :role_name, :target_id, :content, :parse_type, :created_at, :extra)`

	_, err := d.db.NamedExec(query, msg)
	if err != nil {
		log.Warn("db error", zap.Error(err))
	}

	return err
}

func (d *Dao) BatchCreateRoomMessage(ctx context.Context, msgs []model.Message) error {
	log := d.log.With(zap.Any("room_messages", msgs))

	query := `INSERT IGNORE INTO room_message (mid, type, role_id, role_name, target_id, content, parse_type, created_at, extra)
VALUES (:mid, :type, :role_id, :role_name, :target_id, :content, :parse_type, :created_at, :extra)`

	_, err := d.db.NamedExec(query, msgs)
	if err != nil {
		log.Warn("db error", zap.Error(err))
	}

	return err
}

func (d *Dao) CreateBroadcastMessage(ctx context.Context, msg *model.Message) error {
	log := d.log.With(zap.Any("broadcast_message", msg))

	query := `INSERT INTO broadcast_message (mid, type, role_id, role_name, content, parse_type, created_at, extra)
VALUES (:mid, :type, :role_id, :role_name, :content, :parse_type, :created_at, :extra)`

	_, err := d.db.NamedExec(query, msg)
	if err != nil {
		log.Warn("db error", zap.Error(err))
	}

	return err
}

func (d *Dao) BatchCreateBroadcastMessage(ctx context.Context, msgs []model.Message) error {
	log := d.log.With(zap.Any("broadcast_messages", msgs))

	query := `INSERT IGNORE INTO broadcast_message (mid, type, role_id, role_name, content, parse_type, created_at, extra)
VALUES (:mid, :type, :role_id, :role_name, :content, :parse_type, :created_at, :extra)`

	_, err := d.db.NamedExec(query, msgs)
	if err != nil {
		log.Warn("db error", zap.Error(err))
	}

	return err
}

func (d *Dao) GetPrivateMessageList(ctx context.Context, roleID, targetID string, minMid *string, limit int64) (ret []*model.Message, err error) {
	log := d.log.With(
		zap.String("role_id", roleID),
		zap.String("target_id", targetID),
		zap.Stringp("min_mid", minMid),
		zap.Int64("limit", limit),
	)

	ret = make([]*model.Message, 0, limit)
	if minMid == nil {
		err = d.db.Select(&ret, `
			SELECT mid, type, role_id, role_name, target_id, content, parse_type, created_at, extra
			FROM private_message WHERE (role_id = ? AND target_id = ?) OR (role_id = ? AND target_id = ?) ORDER BY mid DESC LIMIT ?;
		`, roleID, targetID, targetID, roleID, limit)
	} else {
		err = d.db.Select(&ret, `
			SELECT mid, type, role_id, role_name, target_id, content, parse_type, created_at, extra
			FROM private_message WHERE ((role_id = ? AND target_id = ?) OR (role_id = ? AND target_id = ?)) AND mid < ? ORDER BY mid DESC LIMIT ?;
		`, roleID, targetID, targetID, roleID, *minMid, limit)
	}
	if err != nil {
		log.Warn("db error", zap.Error(err))
	}
	sort.Slice(ret, func(i, j int) bool {
		return ret[i].Mid < ret[j].Mid
	})

	return
}

func (d *Dao) GetRoomMessageList(ctx context.Context, roomID string, minMid *string, limit int64) (ret []*model.Message, err error) {
	log := d.log.With(
		zap.String("room_id", roomID),
		zap.Stringp("min_mid", minMid),
		zap.Int64("limit", limit),
	)

	ret = make([]*model.Message, 0, limit)
	if minMid == nil {
		err = d.db.Select(&ret, `
			SELECT mid, type, role_id, role_name, target_id, content, parse_type, created_at, extra
			FROM room_message WHERE target_id = ? ORDER BY mid DESC LIMIT ?;
		`, roomID, limit)
	} else {
		err = d.db.Select(&ret, `
			SELECT mid, type, role_id, role_name, target_id, content, parse_type, created_at, extra
			FROM room_message WHERE target_id = ? AND mid < ? ORDER BY mid DESC LIMIT ?;
		`, roomID, *minMid, limit)
	}
	if err != nil {
		log.Warn("db error", zap.Error(err))
	}
	sort.Slice(ret, func(i, j int) bool {
		return ret[i].Mid < ret[j].Mid
	})

	return
}

func (d *Dao) GetBroadcastMessageList(ctx context.Context, minMid *string, limit int64) (ret []*model.Message, err error) {
	log := d.log.With(zap.Stringp("min_mid", minMid), zap.Int64("limit", limit))

	ret = make([]*model.Message, 0, limit)
	if minMid == nil {
		err = d.db.Select(&ret, `
			SELECT mid, type, role_id, role_name, content, parse_type, created_at, extra
			FROM broadcast_message ORDER BY mid DESC LIMIT ?;
		`, limit)
	} else {
		err = d.db.Select(&ret, `
			SELECT mid, type, role_id, role_name, content, parse_type, created_at, extra
			FROM broadcast_message WHERE mid < ? ORDER BY mid DESC LIMIT ?;
		`, *minMid, limit)
	}
	if err != nil {
		log.Warn("db error", zap.Error(err))
	}
	sort.Slice(ret, func(i, j int) bool {
		return ret[i].Mid < ret[j].Mid
	})

	return
}

//func (d *Dao) SaveRoleRoomsToDB(ctx context.Context, data *model.RoleRooms) error {
//	log := d.log.With(zap.Any("data", data))
//
//	query := `INSERT INTO role_rooms (role_id, rooms)
//VALUES (:role_id, :rooms) ON DUPLICATE KEY UPDATE rooms = VALUES(rooms);`
//
//	_, err := d.db.NamedExec(query, data)
//	if err != nil {
//		log.Warn("db error", zap.Error(err))
//	}
//
//	return err
//}
//
//func (d *Dao) BatchSaveRoleRoomsToDB(ctx context.Context, data []*model.RoleRooms) error {
//	log := d.log.With(zap.Any("data", data))
//
//	query := `INSERT INTO role_rooms (role_id, rooms)
//VALUES (:role_id, :rooms) ON DUPLICATE KEY UPDATE rooms = VALUES(rooms);`
//
//	_, err := d.db.NamedExec(query, data)
//	if err != nil {
//		log.Warn("db error", zap.Error(err))
//	}
//
//	return err
//}
//
//func (d *Dao) GetRoleRoomsFromDB(ctx context.Context, roleId string) (ret *model.RoleRooms, err error) {
//	log := d.log.With(zap.String("role_id", roleId))
//
//	ret = &model.RoleRooms{RoleId: roleId, Rooms: "{}"}
//	err = d.db.Get(ret, `
//			SELECT rooms FROM role_rooms WHERE role_id = ?;
//		`, roleId)
//	if err != nil {
//		if err == sql.ErrNoRows {
//			ret.RoomMap = make(map[string]int)
//			return ret, nil
//		}
//		log.Warn("db error", zap.Error(err))
//		return
//	}
//	ret.UnmarshalRooms()
//
//	return
//}
//
//func (d *Dao) BatchGetRoleRoomsFromDB(ctx context.Context, roleIds []string) (ret []*model.RoleRooms, err error) {
//	log := d.log.With(zap.Strings("role_ids", roleIds))
//
//	ret = make([]*model.RoleRooms, 0, len(roleIds))
//	query, args, err := sqlx.In("SELECT role_id, rooms FROM role_rooms WHERE role_id IN (?);", roleIds)
//	query = d.db.Rebind(query)
//
//	err = d.db.Select(&ret, query, args...)
//	if err != nil {
//		log.Warn("db error", zap.Error(err))
//		return
//	}
//
//	roleMap := make(map[string]*model.RoleRooms, len(ret))
//	for _, v := range ret {
//		roleMap[v.RoleId] = v
//	}
//	for _, r := range roleIds {
//		if v, ok := roleMap[r]; ok {
//			v.UnmarshalRooms()
//		} else {
//			ret = append(ret, &model.RoleRooms{RoleId: r, Rooms: "{}", RoomMap: map[string]int{}})
//		}
//	}
//
//	return
//}

func (d *Dao) SaveRoleRoomsToRdb(ctx context.Context, data *model.RoleRooms) error {
	log := d.log.With(zap.Any("data", data))

	err := d.mdb.Set(ctx, data.RdbKey(), data.Rooms, d.conf.RedisRoomsExpires).Err()
	if err != nil {
		log.Warn("rdb error", zap.Error(err))
		return err
	}

	return err
}

func (d *Dao) SaveRoleRooms(ctx context.Context, data *model.RoleRooms) error {
	data.MarshalRooms()
	return d.SaveRoleRoomsToRdb(ctx, data)
}

func (d *Dao) BatchSaveRoleRooms(ctx context.Context, data []*model.RoleRooms) error {
	set := make([]string, 0, len(data)*2)
	for _, r := range data {
		r.MarshalRooms()
		set = append(set, r.RdbKey(), r.Rooms)
	}
	return d.rdb.MSet(ctx, set).Err()
}

func (d *Dao) GetRoleRooms(ctx context.Context, roleId string) (ret *model.RoleRooms, err error) {
	log := d.log.With(zap.String("role_id", roleId))

	ret = &model.RoleRooms{RoleId: roleId}

	ret.Rooms, err = d.mdb.Get(ctx, ret.RdbKey()).Result()
	if err != nil && err != redis.Nil {
		log.Warn("rdb error1", zap.Error(err))
		return nil, err
	}
	ret.UnmarshalRooms()

	return ret, nil
}

func (d *Dao) BatchGetRoleRooms(ctx context.Context, ids []string) (ret []*model.RoleRooms, err error) {
	keys := make([]string, len(ids))
	for i := range ids {
		keys[i] = model.GenRoleRoomsKey(ids[i])
	}

	ifs, err := d.rdb.MGet(ctx, keys...).Result()
	if err != nil {
		return nil, err
	}

	ret = make([]*model.RoleRooms, 0, len(ifs))
	for i, d := range ifs {
		rooms := ""
		if d != nil {
			rooms = d.(string)
		}
		rr := &model.RoleRooms{RoleId: ids[i], Rooms: rooms}
		rr.UnmarshalRooms()
		ret = append(ret, rr)
	}
	return ret, nil
}

func (d *Dao) GetMessageListByRdb(ctx context.Context, key string, limit int64) (ret []*model.Message, err error) {
	log := d.log.With(zap.String("key", key), zap.Int64("limit", limit))

	rdbRet, err := d.rdb.LRange(ctx, key, 0, limit-1).Result()
	if err != nil {
		log.Error("call redis.LRange error", zap.Error(err))
		return
	}

	for _, v := range rdbRet {
		msg := new(cometpb.Message)
		err = msg.Unmarshal([]byte(v))
		if err != nil {
			log.Warn("call msg.Unmarshal error", zap.Error(err))
			continue
		}
		dst := new(model.Message)
		common.TransMessage(msg, dst)
		ret = append(ret, dst)
	}
	sort.Slice(ret, func(i, j int) bool {
		return ret[i].Mid < ret[j].Mid
	})

	return ret, err
}

func (d *Dao) StoreMessageListToRdb(ctx context.Context, key string, data []*model.Message) (err error) {
	if len(data) == 0 {
		return nil
	}
	msgs := make([]interface{}, len(data))
	for i, d := range data {
		msg := new(cometpb.Message)
		common.TransToPbMessage(d, msg)
		msgs[len(msgs)-i-1], _ = msg.Marshal()
	}
	return d.rdb.RPush(ctx, key, msgs...).Err()
}
