package logic

import (
	"net/http"
	"time"

	"coin-im/config"
	"coin-im/internal/dao"

	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis/v8"
	"github.com/segmentio/kafka-go"
	"github.com/ulule/limiter/v3"
	"github.com/ulule/limiter/v3/drivers/store/memory"
	"go.uber.org/zap"
)

type Handler struct {
	conf  *config.RemoteConfig
	dao   *dao.Dao
	rdb   *redis.Client
	log   *zap.Logger
	kw    *kafka.Writer
	limit *limiter.Limiter
}

func NewHandler(conf *config.RemoteConfig, dao *dao.Dao, rdb *redis.Client, log *zap.Logger) *Handler {
	w := &kafka.Writer{
		Addr:         kafka.TCP(conf.KafkaAddr...),
		Topic:        conf.KafkaTopic,
		Balancer:     &kafka.Murmur2Balancer{},
		RequiredAcks: kafka.RequireOne,
		MaxAttempts:  3,
		BatchSize:    200,
		BatchTimeout: 10 * time.Millisecond,
		Async:        true, // TODO 临时改成异步 保证流畅
	}
	rate := limiter.Rate{
		Period: 3 * time.Second,
		Limit:  1,
	}
	store := memory.NewStore()
	return &Handler{conf: conf, dao: dao, rdb: rdb, log: log, kw: w, limit: limiter.New(store, rate)}
}

func (h *Handler) Close() {
	h.kw.Close()
}

func (h *Handler) CheckLimit(c *gin.Context, key string) bool {
	ret, err := h.limit.Get(c, key)
	if err != nil {
		c.JSON(http.StatusInternalServerError, BaseResponse{
			Code:  http.StatusInternalServerError,
			Error: err.Error(),
		})
		return false
	}
	if ret.Reached {
		c.JSON(http.StatusTooManyRequests, BaseResponse{
			Code:  http.StatusTooManyRequests,
			Error: "CD中...",
		})
		return false
	}
	return true
}

type BaseResponse struct {
	Code   int         `json:"code"`
	Error  string      `json:"error,omitempty"`
	Result interface{} `json:"result,omitempty"`
}
