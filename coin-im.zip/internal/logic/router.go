package logic

import (
	"log"
	"net/http"
	"strings"
	"time"

	"coin-im/docs"
	"coin-im/internal/dao"

	"github.com/DeanThompson/ginpprof"
	jwt "github.com/appleboy/gin-jwt/v2"
	"github.com/gin-contrib/cors"
	ginzap "github.com/gin-contrib/zap"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"github.com/go-playground/validator/v10"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
	"go.uber.org/zap"
)

func NewRouter(h *Handler, logger *zap.Logger, debug bool) *gin.Engine {
	gin.SetMode(gin.ReleaseMode)
	if debug {
		gin.SetMode(gin.DebugMode)
	}
	router := gin.New()

	cc := cors.DefaultConfig()
	cc.AllowAllOrigins = true

	router.Use(ginzap.Ginzap(logger, time.RFC3339, false))
	router.Use(ginzap.RecoveryWithZap(logger, true))
	router.Use(cors.New(cc))

	validate := binding.Validator.Engine().(*validator.Validate)
	validate.RegisterValidation("notblank", func(fl validator.FieldLevel) bool {
		switch val := fl.Field().Interface().(type) {
		case string:
			return strings.TrimSpace(val) != ""
		}
		return true
	})

	// the jwt middleware
	authMiddleware, err := jwt.New(&jwt.GinJWTMiddleware{
		Realm:           h.conf.JWTRealm,
		Key:             []byte(h.conf.JWTKey),
		Timeout:         h.conf.JWTTimeout,
		MaxRefresh:      h.conf.JWTMaxRefresh,
		IdentityKey:     dao.IdentityKey,
		PayloadFunc:     h.PayloadFunc,
		IdentityHandler: h.IdentityHandler,
		Authenticator:   h.Authenticator,
		//Authorizator:    h.Authorizator,
		Unauthorized:    h.Unauthorized,
		LoginResponse:   h.LoginRefreshResponse,
		RefreshResponse: h.LoginRefreshResponse,
	})
	if err != nil {
		log.Fatal("JWT Init Error:", zap.Error(err))
	}

	v1 := router.Group("/v1")
	{
		// 服务器使用
		basicAuth := v1.Group("/sys", gin.BasicAuth(h.conf.BasicAuthAccounts))
		{
			basicAuth.GET("/token", authMiddleware.LoginHandler) // 服务器获取token提供给客户端
			basicAuth.Any("/send/private", h.SysSendPrivateMessage)
			basicAuth.POST("/send/room", h.SysSendRoomMessage)
			basicAuth.POST("/send/broadcast", h.SysSendBroadcastMessage)
			basicAuth.POST("/join/room", h.JoinRoom)   // 动态加入房间，如：加入公会
			basicAuth.POST("/leave/room", h.LeaveRoom) // 动态离开房间，如：退出公会
			basicAuth.POST("/blacklist", h.BlackList)  // 禁言&解禁
		}

		// 客户端使用
		auth := v1.Group("", authMiddleware.MiddlewareFunc())
		{
			auth.GET("/refresh_token", authMiddleware.RefreshHandler)
			auth.Any("/send/private", h.SendPrivateMessage)
			auth.POST("/send/room", h.SendRoomMessage)
			auth.POST("/send/broadcast", h.SendBroadcastMessage)
			auth.GET("/message/private", h.GetPrivateMessageList)
			auth.GET("/message/room", h.GetRoomMessageList)
			auth.GET("/message/broadcast", h.GetBroadcastMessageList)
		}
	}

	router.StaticFS("/docs", http.FS(docs.SwaggerFs))
	url := ginSwagger.URL("/docs/swagger.yaml")
	router.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler, url))

	if debug {
		ginpprof.Wrap(router)
	}

	return router
}
