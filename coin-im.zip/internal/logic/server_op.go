package logic

import (
	"net/http"
	"time"

	cometpb "coin-im/api/comet"
	"coin-im/internal/common"
	"coin-im/internal/model"

	"github.com/gin-gonic/gin"
	"github.com/rs/xid"
	"github.com/segmentio/kafka-go"
	"go.uber.org/zap"
)

type SysSendPrivateParams struct {
	RoleID    string `form:"role_id" json:"role_id" binding:"required"`
	RoleName  string `form:"role_name" json:"role_name" binding:"required"`
	TargetID  string `form:"target_id" json:"target_id" binding:"required"`
	Content   string `form:"content" json:"content" binding:"required"`
	ParseType int64  `form:"parse_type" json:"parse_type" binding:"required"`
	Extra     string `form:"extra" json:"extra"` // map[string]string 类型的 json 字符串
}

func (h *Handler) SysSendPrivateMessage(c *gin.Context) {
	var (
		err     error
		code    = http.StatusOK
		msg     string
		message *cometpb.Message
	)

	var params SysSendPrivateParams
	if err = c.ShouldBind(&params); err != nil {
		h.log.Info("parse params failed", zap.Error(err))
		code = http.StatusBadRequest
		msg = err.Error()
		goto Return
	}

	message = &cometpb.Message{
		Type:      cometpb.MsgType_Private,
		Mid:       xid.New().String(),
		RoleId:    params.RoleID,
		RoleName:  params.RoleName,
		TargetId:  params.TargetID,
		Content:   params.Content,
		ParseType: params.ParseType,
		CreatedAt: time.Now().UnixMilli(),
		Extra:     params.Extra,
	}

	err = h.kw.WriteMessages(c, kafka.Message{
		Key:   []byte(message.TargetId),
		Value: cometpb.RawProtoData(message),
	})
	if err != nil {
		h.log.Error("call kafka.WriteMessages error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
	}

Return:
	c.JSON(code, BaseResponse{
		Code:  code,
		Error: msg,
	})
}

type SysSendRoomParams struct {
	RoleID     string `form:"role_id" json:"role_id" binding:"required"`
	RoleName   string `form:"role_name" json:"role_name" binding:"required"`
	TargetID   string `form:"target_id" json:"target_id" binding:"required"`
	Content    string `form:"content" json:"content" binding:"required"`
	ParseType  int64  `form:"parse_type" json:"parse_type" binding:"required"`
	Extra      string `form:"extra" json:"extra"`             // map[string]string 类型的 json 字符串
	IsMarquee  bool   `form:"is_marquee" json:"is_marquee"`   // 是否是跑马灯
	IsVolatile bool   `form:"is_volatile" json:"is_volatile"` // 是否在聊天中显示该消息，例：如果是跑马灯，且该值为true，则不在聊天显示此消息
}

func (h *Handler) SysSendRoomMessage(c *gin.Context) {
	var (
		err     error
		code    = http.StatusOK
		msg     string
		message *cometpb.Message
	)

	var params SysSendRoomParams
	if err = c.ShouldBind(&params); err != nil {
		h.log.Info("parse params failed", zap.Error(err))
		code = http.StatusBadRequest
		msg = err.Error()
		goto Return
	}

	message = &cometpb.Message{
		Type:       cometpb.MsgType_Room,
		Mid:        xid.New().String(),
		RoleId:     params.RoleID,
		RoleName:   params.RoleName,
		TargetId:   params.TargetID,
		Content:    params.Content,
		ParseType:  params.ParseType,
		CreatedAt:  time.Now().UnixMilli(),
		Extra:      params.Extra,
		IsMarquee:  params.IsMarquee,
		IsVolatile: params.IsVolatile,
	}

	err = h.kw.WriteMessages(c, kafka.Message{
		Key:   []byte(message.TargetId),
		Value: cometpb.RawProtoData(message),
	})
	if err != nil {
		h.log.Error("call kafka.WriteMessages error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
	}

Return:
	c.JSON(code, BaseResponse{
		Code:  code,
		Error: msg,
	})
}

type SysSendBroadcastParams struct {
	RoleID     string `form:"role_id" json:"role_id" binding:"required"`
	RoleName   string `form:"role_name" json:"role_name" binding:"required"`
	Content    string `form:"content" json:"content" binding:"required"`
	ParseType  int64  `form:"parse_type" json:"parse_type" binding:"required"`
	Extra      string `form:"extra" json:"extra"`             // map[string]string 类型的 json 字符串
	IsMarquee  bool   `form:"is_marquee" json:"is_marquee"`   // 是否是跑马灯
	IsVolatile bool   `form:"is_volatile" json:"is_volatile"` // 是否在聊天中显示该消息，例：如果是跑马灯，且该值为true，则不在聊天显示此消息
}

func (h *Handler) SysSendBroadcastMessage(c *gin.Context) {
	var (
		err     error
		code    = http.StatusOK
		msg     string
		message *cometpb.Message
	)

	var params SysSendBroadcastParams
	if err = c.ShouldBind(&params); err != nil {
		h.log.Info("parse params failed", zap.Error(err))
		code = http.StatusBadRequest
		msg = err.Error()
		goto Return
	}

	message = &cometpb.Message{
		Type:       cometpb.MsgType_Broadcast,
		Mid:        xid.New().String(),
		RoleId:     params.RoleID,
		RoleName:   params.RoleName,
		Content:    params.Content,
		ParseType:  params.ParseType,
		CreatedAt:  time.Now().UnixMilli(),
		Extra:      params.Extra,
		IsMarquee:  params.IsMarquee,
		IsVolatile: params.IsVolatile,
	}

	err = h.kw.WriteMessages(c, kafka.Message{Value: cometpb.RawProtoData(message)})
	if err != nil {
		h.log.Error("call kafka.WriteMessages error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
	}

Return:
	c.JSON(code, BaseResponse{
		Code:  code,
		Error: msg,
	})
}

type JoinRoomParams struct {
	RoleIDs []string `form:"role_id" json:"role_id" binding:"required"`
	RoomID  string   `form:"room_id" json:"room_id" binding:"required"`
}

func (h *Handler) JoinRoom(c *gin.Context) {
	var (
		err     error
		code    = http.StatusOK
		msg     string
		log     = h.log
		rrs     []*model.RoleRooms
		roleIds []string
	)

	var params JoinRoomParams
	if err = c.ShouldBind(&params); err != nil {
		h.log.Info("parse params failed", zap.Error(err))
		code = http.StatusBadRequest
		msg = err.Error()
		goto Return
	}
	log = log.With(zap.Strings("role_ids", params.RoleIDs), zap.String("room_id", params.RoomID))

	rrs, err = h.dao.BatchGetRoleRooms(c, params.RoleIDs)
	if err != nil {
		log.Error("call dao.BatchGetRoleRooms error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
		goto Return
	}
	roleIds = make([]string, 0, len(rrs))
	for _, r := range rrs {
		r.JoinRoom(params.RoomID)
		roleIds = append(roleIds, r.RoleId)
	}
	err = h.dao.BatchSaveRoleRooms(c, rrs)
	if err != nil {
		log.Error("call dao.SaveRoleRooms error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
		goto Return
	}

	err = h.kw.WriteMessages(c, kafka.Message{
		Value: cometpb.RoomOpProtoData(&cometpb.RoomChange{
			Op:      cometpb.RoomOp_JoinRoom,
			RoomId:  params.RoomID,
			RoleIds: roleIds,
		}),
	})
	switch errs := err.(type) {
	case nil:
	case kafka.WriteErrors:
		if errs[0] != nil {
			log.Error("call kafka.WriteMessages error", zap.Error(errs[0]))
			code = http.StatusInternalServerError
			msg = errs[0].Error()
		}
	default:
		log.Error("call kafka.WriteMessages error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
	}

Return:
	c.JSON(code, BaseResponse{
		Code:  code,
		Error: msg,
	})
}

type LeaveRoomParams struct {
	RoleIDs []string `form:"role_id" json:"role_id" binding:"required"`
	RoomID  string   `form:"room_id" json:"room_id" binding:"required"`
}

func (h *Handler) LeaveRoom(c *gin.Context) {
	var (
		err     error
		code    = http.StatusOK
		msg     string
		rr      []*model.RoleRooms
		roleIds []string
	)

	var params LeaveRoomParams
	if err = c.ShouldBind(&params); err != nil {
		h.log.Info("parse params failed", zap.Error(err))
		code = http.StatusBadRequest
		msg = err.Error()
		goto Return
	}

	rr, err = h.dao.BatchGetRoleRooms(c, params.RoleIDs)
	if err != nil {
		h.log.Error("call dao.GetRoleRooms error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
		goto Return
	}
	roleIds = make([]string, 0, len(rr))
	for _, r := range rr {
		r.LeaveRoom(params.RoomID)
		roleIds = append(roleIds, r.RoleId)
	}
	err = h.dao.BatchSaveRoleRooms(c, rr)
	if err != nil {
		h.log.Error("call dao.SaveRoleRooms error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
		goto Return
	}

	err = h.kw.WriteMessages(c, kafka.Message{
		Value: cometpb.RoomOpProtoData(&cometpb.RoomChange{
			Op:      cometpb.RoomOp_LeaveRoom,
			RoomId:  params.RoomID,
			RoleIds: roleIds,
		}),
	})
	switch errs := err.(type) {
	case nil:
	case kafka.WriteErrors:
		if errs[0] != nil {
			h.log.Error("call kafka.WriteMessages error", zap.Error(errs[0]))
			code = http.StatusInternalServerError
			msg = errs[0].Error()
		}
	default:
		h.log.Error("call kafka.WriteMessages error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
	}

Return:
	c.JSON(code, BaseResponse{
		Code:  code,
		Error: msg,
	})
}

type BlackListParams struct {
	RoleID  string `form:"role_id" json:"role_id" binding:"required"`
	Type    int    `form:"type" json:"type"`       // 类型 1 禁言 0 解禁
	Seconds int    `form:"seconds" json:"seconds"` // 禁言多少秒
}

func (h *Handler) BlackList(c *gin.Context) {
	var (
		err  error
		code = http.StatusOK
		msg  string
	)

	var params BlackListParams
	if err = c.ShouldBind(&params); err != nil {
		h.log.Info("parse params failed", zap.Error(err))
		code = http.StatusBadRequest
		msg = err.Error()
		goto Return
	}

	if params.Type == 1 {
		err = h.rdb.Set(c, common.GenBlackListKey(params.RoleID), "", time.Duration(params.Seconds)*time.Second).Err()
	} else {
		err = h.rdb.Del(c, common.GenBlackListKey(params.RoleID)).Err()
	}
	if err != nil {
		h.log.Error("call rdb.Set error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
		goto Return
	}

Return:
	c.JSON(code, BaseResponse{
		Code:  code,
		Error: msg,
	})
}
