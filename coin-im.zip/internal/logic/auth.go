package logic

import (
	"net/http"
	"time"

	"coin-im/internal/dao"
	"coin-im/pkg/strings"

	jwt "github.com/appleboy/gin-jwt/v2"
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func (h *Handler) PayloadFunc(data interface{}) jwt.MapClaims {
	if v, ok := data.(*dao.AuthPayload); ok {
		return jwt.MapClaims{
			dao.IdentityKey: v.RoleID,
			dao.RoleNameKey: v.RoleName,
			dao.RoomsKey:    v.Rooms,
			dao.ExtraKey:    v.Extra,
		}
	}
	return jwt.MapClaims{}
}

func (h *Handler) IdentityHandler(c *gin.Context) interface{} {
	claims := jwt.ExtractClaims(c)
	rooms := claims[dao.RoomsKey].([]interface{})
	return &dao.AuthPayload{
		RoleID:   claims[dao.IdentityKey].(string),
		RoleName: claims[dao.RoleNameKey].(string),
		Rooms:    strings.FromInterfaces(rooms),
		Extra:    claims[dao.ExtraKey].(string),
	}
}

func (h *Handler) Authenticator(c *gin.Context) (interface{}, error) {
	var payload dao.AuthPayload
	if err := c.ShouldBindQuery(&payload); err != nil {
		h.log.Warn("params parse err", zap.Error(err))
		return nil, err
	}
	if payload.Rooms == nil {
		payload.Rooms = make([]string, 0)
	}
	return &payload, nil
}

func (h *Handler) Unauthorized(c *gin.Context, code int, message string) {
	c.JSON(code, gin.H{
		"code":    code,
		"message": message,
	})
}

func (h *Handler) LoginRefreshResponse(c *gin.Context, code int, token string, expire time.Time) {
	c.JSON(http.StatusOK, BaseResponse{
		Code: code,
		Result: map[string]string{
			"token":  token,
			"expire": expire.Format(time.RFC3339),
		},
	})
}
