package logic

import (
	"context"
	"net/http"
	"sort"
	"strings"
	"time"

	cometpb "coin-im/api/comet"
	"coin-im/internal/common"
	"coin-im/internal/dao"
	"coin-im/internal/model"
	"coin-im/internal/sensitive"

	jwt "github.com/appleboy/gin-jwt/v2"
	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis/v8"
	"github.com/rs/xid"
	"github.com/segmentio/kafka-go"
	"go.uber.org/zap"
)

func (h *Handler) InBlackList(ctx context.Context, roleId string) bool {
	err := h.rdb.Get(ctx, common.GenBlackListKey(roleId)).Err()
	if err != nil {
		if err != redis.Nil {
			h.log.Warn("call rdb.Get error", zap.Error(err), zap.String("role_id", roleId))
		}
		return false
	}
	return true
}

type SendPrivateParams struct {
	TargetID string `form:"target_id" json:"target_id" binding:"required"`
	Content  string `form:"content" json:"content" binding:"required,max=128,notblank"`
}

func (h *Handler) SendPrivateMessage(c *gin.Context) {
	var (
		log       = h.log.With(zap.String("op", "send_private"))
		err       error
		code      = http.StatusOK
		msg       string
		message   *cometpb.Message
		claims, _ = c.Get(dao.IdentityKey)
		payload   = claims.(*dao.AuthPayload)
	)

	var params SendPrivateParams
	if err = c.ShouldBind(&params); err != nil {
		log.Info("parse params failed", zap.Error(err))
		code = http.StatusBadRequest
		msg = err.Error()
		goto Return
	}
	log = log.With(
		zap.String("role_id", payload.RoleID),
		zap.String("role_name", payload.RoleName),
		zap.String("target_id", params.TargetID),
		zap.String("content", params.Content),
	)

	// 禁言判断
	if h.InBlackList(c, payload.RoleID) {
		code = http.StatusForbidden
		msg = "banned to post"
		goto Return
	}

	// 过滤敏感词
	params.Content = sensitive.ChatReplace(params.Content)

	message = &cometpb.Message{
		Type:      cometpb.MsgType_Private,
		Mid:       xid.New().String(),
		RoleId:    payload.RoleID,
		RoleName:  payload.RoleName,
		TargetId:  params.TargetID,
		Content:   params.Content,
		CreatedAt: time.Now().UnixMilli(),
		Extra:     payload.Extra,
	}

	err = h.kw.WriteMessages(c, kafka.Message{
		Key:   []byte(message.TargetId),
		Value: cometpb.RawProtoData(message),
	})
	if err != nil {
		log.Error("call kafka.WriteMessages error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
	}

Return:
	c.JSON(code, BaseResponse{
		Code:  code,
		Error: msg,
	})
}

type SendRoomParams struct {
	TargetID string `form:"target_id" json:"target_id" binding:"required"`
	Content  string `form:"content" json:"content" binding:"required,max=128,notblank"`
}

func (h *Handler) SendRoomMessage(c *gin.Context) {
	var (
		log       = h.log.With(zap.String("op", "send_room"))
		err       error
		code      = http.StatusOK
		msg       string
		message   *cometpb.Message
		claims, _ = c.Get(dao.IdentityKey)
		payload   = claims.(*dao.AuthPayload)
		rr        *model.RoleRooms
	)

	var params SendRoomParams
	if err = c.ShouldBind(&params); err != nil {
		log.Info("parse params failed", zap.Error(err))
		code = http.StatusBadRequest
		msg = err.Error()
		goto Return
	}
	if !h.CheckLimit(c, payload.RoleID) {
		return
	}

	// 禁言判断
	if h.InBlackList(c, payload.RoleID) {
		code = http.StatusForbidden
		msg = "banned to post"
		goto Return
	}

	log = log.With(
		zap.String("role_id", payload.RoleID),
		zap.String("role_name", payload.RoleName),
		zap.String("target_id", params.TargetID),
		zap.String("content", params.Content),
	)

	rr, err = h.dao.GetRoleRooms(c, payload.RoleID)
	if err != nil {
		log.Error("call dao.GetRoleRooms error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
		goto Return
	}
	if !rr.InRoom(params.TargetID) {
		code = http.StatusUnauthorized
		msg = "Unauthorized"
		log.Warn("Unauthorized")
		goto Return
	}

	// 过滤敏感词
	params.Content = sensitive.ChatReplace(params.Content)

	message = &cometpb.Message{
		Type:      cometpb.MsgType_Room,
		Mid:       xid.New().String(),
		RoleId:    payload.RoleID,
		RoleName:  payload.RoleName,
		TargetId:  params.TargetID,
		Content:   params.Content,
		CreatedAt: time.Now().UnixMilli(),
		Extra:     payload.Extra,
	}

	err = h.kw.WriteMessages(c, kafka.Message{
		Key:   []byte(message.TargetId),
		Value: cometpb.RawProtoData(message),
	})
	if err != nil {
		log.Error("call kafka.WriteMessages error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
	}

Return:
	c.JSON(code, BaseResponse{
		Code:  code,
		Error: msg,
	})
}

type SendBroadcastParams struct {
	Content string `form:"content" json:"content" binding:"required,max=128,notblank"`
}

func (h *Handler) SendBroadcastMessage(c *gin.Context) {
	var (
		log       = h.log.With(zap.String("op", "send_broadcast"))
		err       error
		code      = http.StatusOK
		msg       string
		message   *cometpb.Message
		claims, _ = c.Get(dao.IdentityKey)
		payload   = claims.(*dao.AuthPayload)
	)

	var params SendBroadcastParams
	if err = c.ShouldBind(&params); err != nil {
		log.Info("parse params failed", zap.Error(err))
		code = http.StatusBadRequest
		msg = err.Error()
		goto Return
	}
	if !h.CheckLimit(c, payload.RoleID) {
		return
	}

	// 禁言判断
	if h.InBlackList(c, payload.RoleID) {
		code = http.StatusForbidden
		msg = "banned to post"
		goto Return
	}

	log = log.With(
		zap.String("role_id", payload.RoleID),
		zap.String("role_name", payload.RoleName),
		zap.String("content", params.Content),
	)

	// 过滤敏感词
	params.Content = sensitive.ChatReplace(params.Content)

	message = &cometpb.Message{
		Type:      cometpb.MsgType_Broadcast,
		Mid:       xid.New().String(),
		RoleId:    payload.RoleID,
		RoleName:  payload.RoleName,
		Content:   params.Content,
		CreatedAt: time.Now().UnixMilli(),
		Extra:     payload.Extra,
	}

	err = h.kw.WriteMessages(c, kafka.Message{Value: cometpb.RawProtoData(message)})
	if err != nil {
		log.Error("call kafka.WriteMessages error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
	}

Return:
	c.JSON(code, BaseResponse{
		Code:  code,
		Error: msg,
	})
}

type GetPrivateMessageListParams struct {
	TargetID string  `form:"target_id" binding:"required"`
	MinMid   *string `form:"min_mid"`
	Limit    int64   `form:"limit,default=50" binding:"min=1,max=100"`
}

func (h *Handler) GetPrivateMessageList(c *gin.Context) {
	var (
		err    error
		code   = http.StatusOK
		msg    string
		ret    []*model.Message
		claims = jwt.ExtractClaims(c)
		roleID = claims[dao.IdentityKey].(string)
	)

	var params GetPrivateMessageListParams
	if err = c.ShouldBindQuery(&params); err != nil {
		h.log.Info("parse params failed", zap.Error(err))
		code = http.StatusBadRequest
		msg = err.Error()
		goto Return
	}

	// 限制对同一个私聊3秒钟只能拉取一次
	if !h.CheckLimit(c, roleID+params.TargetID) {
		return
	}

	ret, err = h.dao.GetPrivateMessageList(c, roleID, params.TargetID, params.MinMid, params.Limit)
	if err != nil {
		h.log.Error("call dao.CreatePrivateMessage error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
	}

Return:
	c.JSON(code, BaseResponse{
		Code:   code,
		Error:  msg,
		Result: ret,
	})
}

type GetRoomMessageListParams struct {
	TargetID string  `form:"target_id" binding:"required"`
	MinMid   *string `form:"min_mid"`
	Limit    int64   `form:"limit,default=50" binding:"min=1,max=100"`
}

func (h *Handler) GetRoomMessageList(c *gin.Context) {
	var (
		log       = h.log.With(zap.String("op", "get_room"))
		err       error
		code      = http.StatusOK
		msg       string
		ret       []*model.Message
		rr        *model.RoleRooms
		claims, _ = c.Get(dao.IdentityKey)
		payload   = claims.(*dao.AuthPayload)
	)

	var params GetRoomMessageListParams
	if err = c.ShouldBindQuery(&params); err != nil {
		log.Info("parse params failed", zap.Error(err))
		code = http.StatusBadRequest
		msg = err.Error()
		goto Return
	}

	log = log.With(
		zap.String("role_id", payload.RoleID),
		zap.String("role_name", payload.RoleName),
		zap.String("target_id", params.TargetID),
		zap.Stringp("min_mid", params.MinMid),
		zap.Int64("limit", params.Limit),
	)

	rr, err = h.dao.GetRoleRooms(c, payload.RoleID)
	if err != nil {
		log.Error("call dao.GetRoleRooms error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
		goto Return
	}
	if !rr.InRoom(params.TargetID) {
		code = http.StatusUnauthorized
		msg = "Unauthorized"
		log.Warn("Unauthorized")
		goto Return
	}

	if params.MinMid == nil || strings.TrimSpace(*params.MinMid) == "" {
		ret, err = h.dao.GetMessageListByRdb(c, common.GenRdbRoomKey(params.TargetID), params.Limit)
		if err != nil {
			log.Error("call getRedisList error", zap.Error(err))
			code = http.StatusInternalServerError
			msg = err.Error()
		}
		if int64(len(ret)) < params.Limit {
			var minMid *string
			limit := params.Limit
			if len(ret) > 0 {
				minMid = &ret[0].Mid
				limit = params.Limit - int64(len(ret))
			}
			retDB, err := h.dao.GetRoomMessageList(c, params.TargetID, minMid, limit)
			if err != nil {
				log.Error("call dao.GetRoomMessageList0 error", zap.Error(err))
				code = http.StatusInternalServerError
				msg = err.Error()
				goto Return
			}
			if len(retDB) != 0 {
				err = h.dao.StoreMessageListToRdb(c, common.GenRdbRoomKey(params.TargetID), retDB)
				if err != nil {
					log.Error("call h.storeRedisList error", zap.Error(err))
					code = http.StatusInternalServerError
					msg = err.Error()
					goto Return
				}
				ret = append(retDB, ret...)
			}
		}
		h.rdb.Expire(c, common.GenRdbRoomKey(params.TargetID), h.conf.RedisRoomMsgsExpires)
		goto Return
	}

	ret, err = h.dao.GetRoomMessageList(c, params.TargetID, params.MinMid, params.Limit)
	if err != nil {
		log.Error("call dao.GetRoomMessageList1 error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
	}

Return:
	c.JSON(code, BaseResponse{
		Code:   code,
		Error:  msg,
		Result: ret,
	})
}

type GetBroadcastMessageListParams struct {
	MinMid *string `form:"min_mid"`
	Limit  int64   `form:"limit,default=50" binding:"min=1,max=100"`
}

func (h *Handler) GetBroadcastMessageList(c *gin.Context) {
	var (
		err  error
		code = http.StatusOK
		msg  string
		ret  []*model.Message
	)

	var params GetBroadcastMessageListParams
	if err = c.ShouldBindQuery(&params); err != nil {
		h.log.Info("parse params failed", zap.Error(err))
		code = http.StatusBadRequest
		msg = err.Error()
		goto Return
	}

	if params.MinMid == nil || strings.TrimSpace(*params.MinMid) == "" {
		ret, err = h.dao.GetMessageListByRdb(c, common.RdbBroadcastListKey, params.Limit)
		if err != nil {
			h.log.Error("call dao.GetMessageListByRdb error", zap.Error(err))
			code = http.StatusInternalServerError
			msg = err.Error()
			goto Return
		}
		if len(ret) == 0 {
			ret, err = h.dao.GetBroadcastMessageList(c, params.MinMid, params.Limit)
			if err != nil {
				h.log.Error("call dao.GetBroadcastMessageList0 error", zap.Error(err))
				code = http.StatusInternalServerError
				msg = err.Error()
				goto Return
			}
			err = h.dao.StoreMessageListToRdb(c, common.RdbBroadcastListKey, ret)
			if err != nil {
				h.log.Error("call dao.StoreMessageListToRdb error", zap.Error(err))
				code = http.StatusInternalServerError
				msg = err.Error()
				goto Return
			}
		}
		goto Return
	}

	ret, err = h.dao.GetBroadcastMessageList(c, params.MinMid, params.Limit)
	if err != nil {
		h.log.Error("call dao.GetBroadcastMessageList1 error", zap.Error(err))
		code = http.StatusInternalServerError
		msg = err.Error()
	}

Return:
	c.JSON(code, BaseResponse{
		Code:   code,
		Error:  msg,
		Result: ret,
	})
}

func (h *Handler) getRoleRooms(ctx context.Context, key string, limit int64) (ret []*model.Message, err error) {
	rdbRet, err := h.rdb.LRange(ctx, key, 0, limit-1).Result()
	if err != nil {
		h.log.Error("call redis.LRange error", zap.Error(err))
		return
	}

	for _, v := range rdbRet {
		msg := new(cometpb.Message)
		err = msg.Unmarshal([]byte(v))
		if err != nil {
			h.log.Warn("call msg.Unmarshal error", zap.Error(err))
			continue
		}
		dst := new(model.Message)
		common.TransMessage(msg, dst)
		ret = append(ret, dst)
	}
	sort.Slice(ret, func(i, j int) bool {
		return ret[i].Mid < ret[j].Mid
	})

	return ret, err
}
