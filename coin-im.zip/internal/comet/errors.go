package comet

import "errors"

var (
	ErrNotConnectedToImServer = errors.New("not_connected_to_im_server")
)
