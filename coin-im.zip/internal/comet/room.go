package comet

import (
	"sync"
	"sync/atomic"

	"github.com/panjf2000/ants/v2"
)

type Room struct {
	ID      string
	clients *sync.Map
	gopool  *ants.Pool
	online  int32
}

func NewRoom(id string, gopool *ants.Pool) *Room {
	return &Room{ID: id, clients: new(sync.Map), gopool: gopool}
}

func (r *Room) Add(sess *Session) {
	r.clients.Store(sess.ID, sess)
	atomic.AddInt32(&r.online, 1)
}

func (r *Room) Del(sid string) bool {
	r.clients.Delete(sid)
	return atomic.AddInt32(&r.online, -1) == 0
}

func (r *Room) Broadcast(data *Message) {
	r.gopool.Submit(func() {
		r.clients.Range(func(key, value interface{}) bool {
			sess := value.(*Session)
			sess.Push(data)
			return true
		})
	})
}
