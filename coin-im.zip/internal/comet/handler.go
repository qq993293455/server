package comet

import (
	"context"
	"sync"

	"coin-im/config"
	"coin-im/internal/dao"

	"github.com/golang-jwt/jwt/v4"
	"github.com/panjf2000/ants/v2"
	"github.com/panjf2000/gnet"
	"go.uber.org/zap"
)

type Handler struct {
	*gnet.EventServer
	gopool *ants.Pool
	hub    *Hub
	log    *zap.Logger
	conf   *config.RemoteConfig
	dao    *dao.Dao
}

func NewHandler(gopool *ants.Pool, hub *Hub, log *zap.Logger, conf *config.RemoteConfig, dao *dao.Dao) *Handler {
	return &Handler{gopool: gopool, hub: hub, log: log, conf: conf, dao: dao}
}

func (h *Handler) OnOpened(c gnet.Conn) (out []byte, action gnet.Action) {
	h.log.Info("OnConnect ：" + c.RemoteAddr().String())
	c.SetContext(new(sync.Map))
	return
}

func (h *Handler) React(frame []byte, c gnet.Conn) (out []byte, action gnet.Action) {
	op, ok := c.Context().(*sync.Map).Load(CtxOpKey)
	if !ok {
		return
	}

	switch op.(uint16) {
	case OpAuth:
		token, err := jwt.Parse(string(frame), func(token *jwt.Token) (interface{}, error) {
			return []byte(h.conf.JWTKey), nil
		})
		if err != nil {
			out = (&Message{Op: OpAuthReply, Body: []byte(err.Error())}).Packet()
			h.log.Info("Auth token failed", zap.Error(err))
			return out, gnet.Close
		}

		claims := token.Claims.(jwt.MapClaims)
		sid := claims[dao.IdentityKey].(string)

		// 获取房间信息
		rr, err := h.dao.GetRoleRooms(context.Background(), sid)
		if err != nil {
			out = (&Message{Op: OpAuthReply, Body: []byte("err_internal_error")}).Packet()
			h.log.Error("GetRoleRooms failed", zap.Error(err))
			return out, gnet.Close
		}

		// 构造session
		h.log.Info("AddSession : " + sid)
		sess := NewSession(sid, c, h.log)
		sess.Ticker()
		c.Context().(*sync.Map).Store(CtxSessionKey, sess)
		h.hub.AddSession(sess)

		// 加入房间
		for roomID := range rr.RoomMap {
			h.hub.JoinRoomWithSession(roomID, sess)
			h.log.Info("Join room: " + sid + " -> " + roomID)
		}

		out = (&Message{Op: OpAuthReply, Body: []byte("ok")}).Packet()
		h.log.Info("AddSession success : " + sid)
	case OpPing:
		if value, ok := c.Context().(*sync.Map).Load(CtxSessionKey); ok {
			sess := value.(*Session)
			sess.Ping()
		}
		out = (&Message{Op: OpPong}).Packet()
	}

	return
}

func (h *Handler) OnClosed(c gnet.Conn, err error) (action gnet.Action) {
	h.log.Info("OnClosed : "+c.RemoteAddr().String(), zap.Error(err))
	if value, ok := c.Context().(*sync.Map).Load(CtxSessionKey); ok {
		sess := value.(*Session)
		h.hub.DelSession(sess)
		h.log.Info("DelSession : " + sess.ID)
	}
	return
}
