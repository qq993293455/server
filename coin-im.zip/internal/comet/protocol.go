package comet

import (
	"encoding/binary"
	"sync"

	"github.com/panjf2000/gnet"
)

const (
	OpPing = uint16(1)
	OpPong = uint16(2)

	// OpAuth auth connnect
	OpAuth = uint16(7)
	// OpAuthReply auth connect reply
	OpAuthReply = uint16(8)

	// OpRaw raw message
	OpRaw = uint16(9)
)

const (
	// size
	_packSize      = 4
	_headerSize    = 2
	_opSize        = 2
	_rawHeaderSize = _packSize + _headerSize + _opSize

	_headerLen = _opSize

	// offset
	_packOffset   = 0
	_headerOffset = _packOffset + _packSize
	_opOffset     = _headerOffset + _opSize
)

const (
	CtxOpKey      = "ctx_op_key"
	CtxMessageKey = "ctx_message_key"
	CtxSessionKey = "ctx_session_key"
)

// Message | packLen 4B | headerLen 2B | op 2B | body ... |
type Message struct {
	Op   uint16
	Body []byte
}

func (m *Message) Packet() []byte {
	dataLen := len(m.Body)
	packLen := uint32(dataLen + _rawHeaderSize)
	ret := make([]byte, packLen)

	binary.BigEndian.PutUint32(ret, packLen)
	binary.BigEndian.PutUint16(ret[_headerOffset:], _headerLen)
	binary.BigEndian.PutUint16(ret[_opOffset:], m.Op)
	copy(ret[_rawHeaderSize:], m.Body)

	return ret
}

func (m *Message) Reset() {
	*m = Message{}
}

type protocol struct{}

func (d *protocol) Decode(c gnet.Conn) (out []byte, err error) {
	if c.BufferLength() < _rawHeaderSize {
		return
	}

	_, lenData := c.ReadN(_packSize)
	length := binary.BigEndian.Uint32(lenData)
	if c.BufferLength() < int(length) {
		return
	}
	c.ShiftN(_packSize)

	_, headerLenData := c.ReadN(_headerSize)
	headerLen := int(binary.BigEndian.Uint16(headerLenData))
	c.ShiftN(_headerSize)

	_, headerData := c.ReadN(headerLen)
	c.ShiftN(headerLen)

	op := binary.BigEndian.Uint16(headerData[:_opSize])

	dataLen := length - _packSize - uint32(headerLen) - _headerSize
	_, out = c.ReadN(int(dataLen))
	c.ShiftN(int(dataLen))

	c.Context().(*sync.Map).Store(CtxOpKey, op)
	return
}

func (d *protocol) Encode(c gnet.Conn, data []byte) ([]byte, error) {
	return data, nil
}

var Protocol = &protocol{}
