package comet

import (
	"context"
	"sync"
	"sync/atomic"
	"time"

	cometpb "coin-im/api/comet"
	"coin-im/config"
	"coin-im/pkg/util"

	"github.com/panjf2000/ants/v2"
	"github.com/segmentio/kafka-go"
	"go.uber.org/zap"
)

type Hub struct {
	conf     *config.RemoteConfig
	sessions *sync.Map // 所有连接
	rooms    *sync.Map
	gopool   *ants.Pool
	log      *zap.Logger
	online   int32
	kr       *kafka.Reader

	close  chan struct{}
	closed int32
}

func NewHub(conf *config.RemoteConfig, gopool *ants.Pool, log *zap.Logger) *Hub {
	setConsumerGroupOffset(conf, kafka.LastOffset) // 启动时从最新消息开始读
	kr := kafka.NewReader(kafka.ReaderConfig{
		Brokers: conf.KafkaAddr,
		GroupID: conf.KafkaEnv.CometGroup,
		Topic:   conf.KafkaTopic,
		//MinBytes:       10e3, // 10KB
		MaxBytes:       50e6, // 50MB
		StartOffset:    kafka.LastOffset,
		CommitInterval: 1 * time.Millisecond,
	})

	hub := &Hub{conf: conf, sessions: new(sync.Map), rooms: new(sync.Map), gopool: gopool, log: log, kr: kr, close: make(chan struct{})}
	go hub.kafkaConsume()

	return hub
}

func setConsumerGroupOffset(conf *config.RemoteConfig, offset int64) {
	group, err := kafka.NewConsumerGroup(kafka.ConsumerGroupConfig{
		Brokers: conf.KafkaAddr,
		ID:      conf.KafkaEnv.CometGroup,
		Topics:  []string{conf.KafkaTopic},
	})
	util.Must(err)
	defer group.Close()

	gen, err := group.Next(context.Background())
	if err != nil {
		return
	}

	offsets := make(map[string]map[int]int64)
	for topic, pas := range gen.Assignments {
		for _, pa := range pas {
			if _, ok := offsets[topic]; ok {
				offsets[topic][pa.ID] = offset
			} else {
				offsets[topic] = make(map[int]int64)
				offsets[topic][pa.ID] = offset
			}
		}
	}
	util.Must(gen.CommitOffsets(offsets))
}

func (h *Hub) AddSession(sess *Session) {
	old, ok := h.sessions.LoadAndDelete(sess.ID)
	if ok {
		h.DelSession(old.(*Session))
	}
	h.sessions.Store(sess.ID, sess)
	atomic.AddInt32(&h.online, 1)
}

func (h *Hub) DelSession(sess *Session) {
	h.sessions.Delete(sess.ID)
	sess.Close()
	atomic.AddInt32(&h.online, -1)
}

func (h *Hub) GetSession(sid string) (c *Session, ok bool) {
	if val, ok := h.sessions.Load(sid); ok {
		return val.(*Session), ok
	}
	return nil, false
}

// JoinRoom 进入房间/频道
func (h *Hub) JoinRoom(roomID, sid string) error {
	sess, ok := h.GetSession(sid)
	if !ok {
		return ErrNotConnectedToImServer
	}
	val, _ := h.rooms.LoadOrStore(roomID, NewRoom(roomID, h.gopool))
	room := val.(*Room)
	room.Add(sess)
	sess.OnClose(func() {
		room.Del(sess.ID)
	})
	return nil
}

// BatchJoinRoom 批量用户进入房间/频道
func (h *Hub) BatchJoinRoom(roomID string, sids []string) {
	val, _ := h.rooms.LoadOrStore(roomID, NewRoom(roomID, h.gopool))
	room := val.(*Room)

	for _, sid := range sids {
		sess, ok := h.GetSession(sid)
		if !ok {
			continue
		}
		room.Add(sess)
		sess.OnClose(func() {
			room.Del(sess.ID)
		})
	}
}

// JoinRoomWithSession 进入房间/频道
func (h *Hub) JoinRoomWithSession(roomID string, sess *Session) {
	val, _ := h.rooms.LoadOrStore(roomID, NewRoom(roomID, h.gopool))
	room := val.(*Room)
	room.Add(sess)
	sess.OnClose(func() {
		room.Del(sess.ID)
	})
}

// LeaveRoom 离开房间/频道
func (h *Hub) LeaveRoom(roomID, sid string) {
	val, _ := h.rooms.LoadOrStore(roomID, NewRoom(roomID, h.gopool))
	room := val.(*Room)
	room.Del(sid)
}

// BatchLeaveRoom 批量用户离开房间/频道
func (h *Hub) BatchLeaveRoom(roomID string, sids []string) {
	val, _ := h.rooms.LoadOrStore(roomID, NewRoom(roomID, h.gopool))
	room := val.(*Room)
	for _, sid := range sids {
		room.Del(sid)
	}
}

// Push 私聊推送
func (h *Hub) Push(sid string, data *Message) {
	if value, ok := h.sessions.Load(sid); ok {
		c := value.(*Session)
		if err := c.Push(data); err != nil {
			h.log.Warn("Push error", zap.Error(err))
		}
	}
}

// RoomBroadcast 指定房间/频道广播
func (h *Hub) RoomBroadcast(roomID string, data *Message) {
	if value, ok := h.rooms.Load(roomID); ok {
		room := value.(*Room)
		room.Broadcast(data)
	}
}

// Broadcast 世界聊天广播
func (h *Hub) Broadcast(data *Message) {
	h.gopool.Submit(func() {
		h.sessions.Range(func(key, value interface{}) bool {
			c := value.(*Session)
			c.Push(data)
			return true
		})
	})
}

var (
	protoPool   = sync.Pool{New: func() interface{} { return new(cometpb.Proto) }}
	messagePool = sync.Pool{New: func() interface{} { return new(cometpb.Message) }}
)

func protoPoolPut(p *cometpb.Proto) {
	p.Reset()
	protoPool.Put(p)
}

func messagePoolPut(p *cometpb.Message) {
	p.Reset()
	messagePool.Put(p)
}

func (h *Hub) kafkaConsume() {
	ctx := context.Background()
	for {
		select {
		case <-h.close:
			atomic.StoreInt32(&h.closed, 1)
			return
		default:
		}

		msg, err := h.kr.FetchMessage(ctx)
		if err != nil {
			h.log.Warn("call kafka.FetchMessage failed", zap.Error(err))
			continue
		}

		h.log.Info("received message.", zap.String("topic", msg.Topic), zap.Int("partition", msg.Partition), zap.Int64("offset", msg.Offset))

		proto := protoPool.Get().(*cometpb.Proto)
		err = proto.Unmarshal(msg.Value)
		if err != nil {
			h.log.Warn("call proto.Unmarshal failed", zap.Error(err))
			protoPoolPut(proto)
			continue
		}

		switch proto.Type {
		case cometpb.ProtoType_Raw:
			h.processRaw(proto.Body)
		case cometpb.ProtoType_OpRoom:
			h.processOpRoom(proto.Body)
		default:
			h.log.Warn("unknown ProtoType", zap.Int32("proto_type", int32(proto.Type)))
		}

		protoPoolPut(proto)
		if err = h.kr.CommitMessages(ctx, msg); err != nil {
			h.log.Warn("call kafka.CommitMessages failed", zap.Error(err))
		}
	}
}

func (h *Hub) processRaw(body []byte) {
	message := messagePool.Get().(*cometpb.Message)
	defer messagePoolPut(message)

	err := message.Unmarshal(body)
	if err != nil {
		h.log.Warn("call message.Unmarshal failed", zap.Error(err))
		return
	}

	switch message.Type {
	case cometpb.MsgType_Private:
		h.Push(message.TargetId, &Message{
			Op:   OpRaw,
			Body: body,
		})
		h.Push(message.RoleId, &Message{
			Op:   OpRaw,
			Body: body,
		})
	case cometpb.MsgType_Room:
		h.RoomBroadcast(message.TargetId, &Message{
			Op:   OpRaw,
			Body: body,
		})
	case cometpb.MsgType_Broadcast:
		h.Broadcast(&Message{
			Op:   OpRaw,
			Body: body,
		})
	default:
		h.log.Warn("unknown MsgType", zap.Int32("msg_type", int32(message.Type)))
	}
}

func (h *Hub) processOpRoom(body []byte) {
	rc := new(cometpb.RoomChange)
	err := rc.Unmarshal(body)
	if err != nil {
		h.log.Warn("call roomChange.Unmarshal failed", zap.Error(err))
		return
	}

	switch rc.Op {
	case cometpb.RoomOp_JoinRoom:
		h.BatchJoinRoom(rc.RoomId, rc.RoleIds)
	case cometpb.RoomOp_LeaveRoom:
		h.BatchLeaveRoom(rc.RoomId, rc.RoleIds)
	default:
		h.log.Warn("unknown RoomOp", zap.Int32("room_op", int32(rc.Op)))
	}
}

func (h *Hub) Close(ctx context.Context) error {
	close(h.close)
	h.kr.Close()

	ticker := time.NewTicker(10 * time.Millisecond)
	defer ticker.Stop()

	for {
		if atomic.LoadInt32(&h.closed) == 1 {
			return nil
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
		}
	}
}
