package comet

import (
	"time"

	"coin-im/pkg/timer"

	"github.com/panjf2000/gnet"
	"go.uber.org/atomic"
	"go.uber.org/zap"
)

const (
	PingInterval = 10 * time.Second
	PingTimeout  = 3 * PingInterval
)

type Session struct {
	ID       string // RoleId
	conn     gnet.Conn
	onClose  []func()
	log      *zap.Logger
	closed   *atomic.Bool
	LastPing time.Time
}

func NewSession(id string, conn gnet.Conn, log *zap.Logger) *Session {
	return &Session{
		ID:       id,
		conn:     conn,
		log:      log,
		closed:   atomic.NewBool(false),
		LastPing: time.Now(),
	}
}

func (s *Session) Push(data *Message) error {
	return s.conn.AsyncWrite(data.Packet())
}

func (s *Session) Close() {
	s.closed.Store(true)
	s.conn.Close()
	for _, f := range s.onClose {
		f()
	}
}

func (s *Session) OnClose(f func()) {
	s.onClose = append(s.onClose, f)
}

func (s *Session) Ping() {
	s.LastPing = time.Now()
}

func (s *Session) Ticker() {
	// 判断是否断线
	timer.Ticker(PingTimeout, func() bool {
		if s.closed.Load() {
			return false
		}
		timeout := time.Now().Sub(s.LastPing) >= PingTimeout
		if timeout {
			s.log.Warn("ping timeout", zap.String("session id", s.ID))
			s.Close()
		}
		return !timeout
	})
}
