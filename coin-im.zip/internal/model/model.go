package model

import (
	"coin-im/pkg/util"

	jsoniter "github.com/json-iterator/go"
)

const (
	MsgTypePrivate = iota
	MsgTypeRoom
	MsgTypeBroadcast
	MsgTypeFill
)

type Message struct {
	Mid       string `db:"mid" json:"mid"`
	Type      int    `db:"type" json:"type"`
	RoleId    string `db:"role_id" json:"role_id"`
	RoleName  string `db:"role_name" json:"role_name"`
	TargetId  string `db:"target_id" json:"target_id,omitempty"`
	Content   string `db:"content" json:"content"`
	ParseType int64  `db:"parse_type" json:"parse_type"` // game server 自定义的解析类型 默认0为正常聊天消息
	CreatedAt int64  `db:"created_at" json:"created_at"`
	Extra     string `db:"extra" json:"extra"` // 扩展字段 map[string]string的json字符串
}

func (m *Message) ToJSON() []byte {
	ret, _ := jsoniter.Marshal(m)
	return ret
}

func (m *Message) Reset() {
	*m = Message{}
}

type RoleRooms struct {
	RoleId  string `db:"role_id" json:"role_id"`
	Rooms   string `db:"rooms" json:"rooms"`
	RoomMap map[string]int
}

func (r *RoleRooms) JoinRoom(room string) {
	r.RoomMap[room] = 1
}

func (r *RoleRooms) LeaveRoom(room string) {
	delete(r.RoomMap, room)
}

func (r *RoleRooms) InRoom(room string) bool {
	_, ok := r.RoomMap[room]
	return ok
}

func (r *RoleRooms) MarshalRooms() {
	var err error
	r.Rooms, err = jsoniter.MarshalToString(r.RoomMap)
	util.Must(err)
}

func (r *RoleRooms) UnmarshalRooms() {
	err := jsoniter.UnmarshalFromString(r.Rooms, &r.RoomMap)
	if err != nil {
		r.RoomMap = make(map[string]int)
	}
}

func (r *RoleRooms) RdbKey() string {
	return GenRoleRoomsKey(r.RoleId)
}

const baseRoleRoomsKey = "im:role_rooms:"

func GenRoleRoomsKey(roleId string) string {
	return baseRoleRoomsKey + roleId
}
