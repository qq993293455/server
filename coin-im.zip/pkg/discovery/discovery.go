package discovery

import (
	"context"
	"sync/atomic"
	"time"

	consul "github.com/hashicorp/consul/api"
)

type Service struct {
	ID       string
	Name     string
	Tags     []string
	Address  string
	Port     int
	Metadata map[string]string
}

type Discovery interface {
	GetServices(ctx context.Context, name string, tag string) ([]*Service, error)
	Register(ctx context.Context, svc *Service) error
	Deregister(ctx context.Context, serviceID string) error
}

type Consul struct {
	cli       *consul.Client
	svcs      []*Service
	flag      int32
	lastIndex uint64
}

func NewConsul(namespace, address string) (Discovery, error) {
	cfg := consul.DefaultConfig()
	cfg.Namespace = namespace
	cfg.Address = address
	cli, err := consul.NewClient(cfg)
	if err != nil {
		return nil, err
	}
	return &Consul{cli: cli}, nil
}

func (c *Consul) GetServices(ctx context.Context, name string, tag string) ([]*Service, error) {
	if len(c.svcs) != 0 || atomic.LoadInt32(&c.flag) == 1 {
		return c.svcs, nil
	}

	c.loadServices(name, tag, true, nil)

	if atomic.CompareAndSwapInt32(&c.flag, 0, 1) {
		go func() {
			for {
				select {
				case <-ctx.Done():
					return
				default:
					c.loadServices(name, tag, true, &consul.QueryOptions{WaitIndex: c.lastIndex})
				}
			}
		}()
	}

	return c.svcs, nil
}

func (c *Consul) loadServices(name, tag string, passingOnly bool, q *consul.QueryOptions) {
	ses, meta, err := c.cli.Health().Service(name, tag, passingOnly, q)
	if err != nil {
		return
	}

	c.svcs = make([]*Service, 0, len(ses))
	for _, se := range ses {
		c.svcs = append(c.svcs, &Service{
			ID:       se.Service.ID,
			Name:     se.Service.Service,
			Tags:     se.Service.Tags,
			Address:  se.Service.Address,
			Port:     se.Service.Port,
			Metadata: se.Service.Meta,
		})
	}

	c.lastIndex = meta.LastIndex
}

func (c *Consul) Register(ctx context.Context, svc *Service) error {
	err := c.cli.Agent().ServiceRegister(&consul.AgentServiceRegistration{
		ID:      svc.ID,
		Name:    svc.Name,
		Tags:    svc.Tags,
		Port:    svc.Port,
		Address: svc.Address,
		Meta:    svc.Metadata,
		Check: &consul.AgentServiceCheck{
			TTL: "15s",
		},
	})
	if err != nil {
		return err
	}

	go func() {
		for {
			select {
			case <-ctx.Done():
				return
			default:
				c.cli.Agent().UpdateTTL("service:"+svc.ID, "", consul.HealthPassing)
				time.Sleep(5 * time.Second)
			}
		}
	}()

	return nil
}

func (c *Consul) Deregister(ctx context.Context, serviceID string) error {
	return c.cli.Agent().ServiceDeregister(serviceID)
}
