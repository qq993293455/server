package strings

func FromInterfaces(vals []interface{}) []string {
	ret := make([]string, 0, len(vals))
	for _, v := range vals {
		if s, ok := v.(string); ok {
			ret = append(ret, s)
		}
	}
	return ret
}

func FromMapInterfaces(vals map[string]interface{}) map[string]string {
	ret := make(map[string]string, len(vals))
	for k, v := range vals {
		if s, ok := v.(string); ok {
			ret[k] = s
		}
	}
	return ret
}
