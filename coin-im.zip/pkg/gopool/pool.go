package gopool

import (
	"github.com/panjf2000/ants/v2"
)

var pool *ants.Pool

func init() {
	var err error
	pool, err = ants.NewPool(50000)
	if err != nil {
		panic(err)
	}
}

func Submit(f func()) {
	_ = pool.Submit(f)
}
