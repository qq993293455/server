#gopool

全局化 github.com/panjf2000/ants/v2

使用时直接:
```go
gopool.Submit(func(){})
```
