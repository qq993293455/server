//go:build linux
// +build linux

package reuseport

const soReusePort = 0x0F
