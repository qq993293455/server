package remotecfg

import (
	"errors"
	"path"
	"strings"

	"coin-im/config"
	"coin-im/pkg/util"

	"github.com/kelseyhightower/envconfig"
	"github.com/spf13/viper"
	_ "github.com/spf13/viper/remote"
)

// ConfigCenter 支持多个文件的配置
var ConfigCenter *configCenter

var Env *config.EnvConfig

type configCenter struct {
	vs map[string]*viper.Viper
}

func InitConfig() {
	Env = new(config.EnvConfig)
	err := envconfig.Process("im", Env)
	util.Must(err)

	if ConfigCenter != nil {
		return
	}
	ConfigCenter = &configCenter{
		vs: make(map[string]*viper.Viper, 0),
	}
	return
}

func (cfg *configCenter) RegisterConfig(name string, p string) {
	v := viper.New()
	cfg.vs[name] = v
	providers := strings.Split(Env.Remote, ",")
	var err error
	for _, provider := range providers {
		err = v.AddRemoteProvider(Env.RemoteType, provider, path.Join(Env.ConfPath, p))
		if err != nil {
			continue
		}
	}
	v.SetConfigType(Env.ConfFormat)
	err = v.ReadRemoteConfig()
	if err != nil {
		panic(err)
	}
	cfg.startWatch(v)
}

func (cfg *configCenter) GetConfig(name string) *viper.Viper {
	conf, ok := cfg.vs[name]
	if !ok {
		err := errors.New("ConfigCenter: no exist conf")
		panic(err)
	}
	return conf
}

func (cfg *configCenter) GetConfigWithType(name string, typ string) *viper.Viper {
	conf, ok := cfg.vs[name]
	if !ok {
		err := errors.New("ConfigCenter: no exist conf")
		panic(err)
	}
	if typ == "" {
		typ = Env.ConfFormat
	}
	conf.SetConfigType(typ)
	return conf
}

func (cfg *configCenter) startWatch(v *viper.Viper) {
	err := v.WatchRemoteConfigOnChannel()
	if err != nil {
		panic(err)
	}
}
