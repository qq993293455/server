package time

const (
	// Debug debug switch
	Debug = false
)
