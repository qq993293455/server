package comet

func RawProtoData(message *Message) (data []byte) {
	body, _ := message.Marshal()
	proto := &Proto{
		Type: ProtoType_Raw,
		Body: body,
	}
	data, _ = proto.Marshal()
	return
}

func RoomOpProtoData(rc *RoomChange) (data []byte) {
	body, _ := rc.Marshal()
	proto := &Proto{
		Type: ProtoType_OpRoom,
		Body: body,
	}
	data, _ = proto.Marshal()
	return
}
