package config

import "time"

type EnvConfig struct {
	Remote     string `default:"10.23.20.53:8500,10.23.20.53:8501,10.23.20.53:8502" split_words:"true" desc:"配置中心地址"`
	RemoteType string `default:"consul" split_words:"true" desc:"配置中心类型"`
	ConfPath   string `default:"coin-im" split_words:"true" desc:"配置文件路径"`
	ConfFormat string `default:"json" split_words:"true" desc:"配置文件类型"`
}

type KafkaEnvConfig struct {
	CometGroup         string `default:"coin-im-comet-1" split_words:"true" desc:"comet 服务消费组 每个 comet 都不一样 // comet"`
	DBWorkerGroup      string `default:"coin-im-dbworker-1" split_words:"true" desc:"dbworker mysql 服务消费组 每个 dbworker 都一样 // dbworker"`
	DBWorkerRedisGroup string `default:"coin-im-dbworker-redis-1" split_words:"true" desc:"dbworker redis 服务消费组 每个 dbworker 都一样 // dbworker"`
}

type RedisConfig struct {
	Addr     string `mapstructure:"addr" default:"10.23.20.53:6379"`
	Password string `mapstructure:"password" default:"iggcdl5,."`
	DB       int    `mapstructure:"db"`
	TLS      bool   `mapstructure:"tls"`
}

type RemoteConfig struct {
	TcpAddr   string `mapstructure:"tcp_addr" default:"0.0.0.0:9527" desc:"comet 监听地址 // comet"`
	HttpAddr  string `mapstructure:"http_addr" default:"0.0.0.0:9528" desc:"logic 监听地址 // logic"`
	HttpsAddr string `mapstructure:"https_addr" default:"0.0.0.0:9529" desc:"logic https 监听地址 // logic"`

	DSN string `mapstructure:"dsn" default:"root:F3xS!UB8PYGs@tcp(10.23.20.53:3306)/im" desc:"MySQL 地址 // logic,dbworker"`

	BasicAuthAccounts map[string]string `mapstructure:"basic_auth_accounts" default:"{\"demo\":\"Nsv2X$hhUqA&7E\"}" desc:"GameServer BasicAuth 账户 // logic"`

	JWTRealm      string        `mapstructure:"jwt_realm" default:"coin-im" desc:" // logic"`
	JWTKey        string        `mapstructure:"jwt_key" default:"GV2orbYU9rg^8Va!iAxHSWIh092F394m7&srqakD7M%2@JYnwi" desc:" // logic,comet"`
	JWTTimeout    time.Duration `mapstructure:"jwt_timeout" default:"720h" desc:" // logic"`
	JWTMaxRefresh time.Duration `mapstructure:"jwt_max_refresh" default:"744h" desc:" // logic"`

	Debug bool `mapstructure:"debug" default:"true" desc:"是否开启 debug  // all"`

	KafkaAddr  []string `mapstructure:"kafka_addr" default:"[\"10.23.20.53:49156\"]" desc:"kafka 地址 // logic,comet,dbworker"`
	KafkaTopic string   `mapstructure:"kafka_topic" default:"coin-im" desc:"kafka topic // logic,comet,dbworker"`

	Redis                *RedisConfig  `mapstructure:"redis"`
	RedisListSize        int64         `mapstructure:"redis_list_size" default:"100" desc:"redis 缓存多少条数据 // logic,dbworker"`
	RedisRoomsExpires    time.Duration `mapstructure:"redis_rooms_expires" default:"1800s" desc:"redis 用户房间 缓存多久 // logic,dbworker"`
	RedisRoomMsgsExpires time.Duration `mapstructure:"redis_room_msgs_expires" default:"180s" desc:"redis 房间消息 缓存多久 // logic,dbworker"`

	MemoryDB *RedisConfig `mapstructure:"memory_db"`

	RuleAddr   string `mapstructure:"rule_addr" default:"http://10.23.20.53:8065" desc:"规则中心地址"`
	RuleBranch string `mapstructure:"rule_branch" default:"develop" desc:"规则分支"`

	KafkaEnv       *KafkaEnvConfig `mapstructure:",omitempty"`
	PprofAddr      string          `mapstructure:"pprof_addr" default:":8861" desc:"pprof地址"`
	LogicPprofAddr string          `mapstructure:"logic_pprof_addr" default:":8862" desc:"logic pprof地址"`
}
